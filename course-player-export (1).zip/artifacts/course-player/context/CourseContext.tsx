import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';

export type SupportedFileType = 'video' | 'pdf' | 'image' | 'code' | 'docx';

export interface CourseFile {
  name: string;
  uri: string;
  type: SupportedFileType;
  completed: boolean;
  watchedSeconds?: number;
  durationSeconds?: number;
}

export interface Course {
  id: string;
  name: string;
  dirUri: string;
  files: CourseFile[];
  totalVideos: number;
  completedVideos: number;
  percentComplete: number;
}

export interface ResumeState {
  courseId: string;
  courseName: string;
  fileName: string;
  fileUri: string;
  fileType: SupportedFileType;
  watchedSeconds: number;
  durationSeconds: number;
}

export interface DailyStudy {
  date: string;
  minutesWatched: number;
}

export interface ProgressData {
  [courseId: string]: {
    [fileName: string]: {
      completed: boolean;
      watchedSeconds: number;
      durationSeconds: number;
    };
  };
}

interface CourseContextType {
  courses: Course[];
  resume: ResumeState | null;
  dailyStudy: DailyStudy;
  rootFolderUri: string | null;
  fixedRootFolderUri: string;
  isLoading: boolean;
  loadCourses: () => Promise<void>;
  updateProgress: (
    courseId: string,
    fileName: string,
    watchedSeconds: number,
    durationSeconds: number
  ) => Promise<void>;
  markFileComplete: (courseId: string, fileName: string) => Promise<void>;
  setResumeState: (state: ResumeState) => Promise<void>;
  addStudyMinutes: (minutes: number) => Promise<void>;
  getCourseById: (id: string) => Course | undefined;
}

const CourseContext = createContext<CourseContextType | null>(null);

const STORAGE_KEYS = {
  PROGRESS: '@course_progress',
  RESUME: '@course_resume',
  DAILY_STUDY: '@course_daily_study',
};

const FIXED_ROOT_FOLDER = '/storage/emulated/0/Courses';

const CODE_EXTS = [
  'js','ts','jsx','tsx','py','java','kt','swift','c','cpp','cs','go','rs','rb',
  'php','sh','bash','html','css','scss','sass','less','json','xml','yaml','yml',
  'toml','ini','md','markdown','txt','sql','r','dart','lua','pl','m','vue','svelte',
  'graphql','gql','env','gitignore','dockerfile',
];

function getFileType(name: string): SupportedFileType | null {
  const ext = name.toLowerCase().split('.').pop() ?? '';
  if (['mp4', 'mov', 'mkv', 'm4v', 'avi', 'webm', 'm3u8'].includes(ext)) return 'video';
  if (ext === 'pdf') return 'pdf';
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'heic'].includes(ext)) return 'image';
  if (['docx', 'doc'].includes(ext)) return 'docx';
  if (CODE_EXTS.includes(ext) || CODE_EXTS.includes(name.toLowerCase())) return 'code';
  return null;
}

function getTodayString(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function CourseProvider({ children }: { children: React.ReactNode }) {
  const [courses, setCourses] = useState<Course[]>([]);
  const [resume, setResume] = useState<ResumeState | null>(null);
  const [dailyStudy, setDailyStudy] = useState<DailyStudy>({ date: getTodayString(), minutesWatched: 0 });
  const [rootFolderUri, setRootFolderUri] = useState<string | null>(FIXED_ROOT_FOLDER);
  const [progress, setProgress] = useState<ProgressData>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadStoredData();
  }, []);

  const loadStoredData = async () => {
    try {
      const [storedProgress, storedResume, storedDaily] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.PROGRESS),
        AsyncStorage.getItem(STORAGE_KEYS.RESUME),
        AsyncStorage.getItem(STORAGE_KEYS.DAILY_STUDY),
      ]);

      const parsedProgress: ProgressData = storedProgress ? JSON.parse(storedProgress) : {};
      setProgress(parsedProgress);

      if (storedResume) setResume(JSON.parse(storedResume));

      const today = getTodayString();
      if (storedDaily) {
        const parsed: DailyStudy = JSON.parse(storedDaily);
        if (parsed.date === today) {
          setDailyStudy(parsed);
        } else {
          setDailyStudy({ date: today, minutesWatched: 0 });
        }
      }

      setRootFolderUri(FIXED_ROOT_FOLDER);
      await scanCoursesFromStorage(FIXED_ROOT_FOLDER, parsedProgress);
    } catch (e) {
      console.error('Error loading stored data:', e);
    }
  };

  const scanCoursesFromStorage = async (folderUri: string, progressData: ProgressData) => {
    try {
      setIsLoading(true);
      const dirInfo = await FileSystem.getInfoAsync(folderUri);
      if (!dirInfo.exists || !dirInfo.isDirectory) {
        setIsLoading(false);
        return;
      }

      const subdirs = await FileSystem.readDirectoryAsync(folderUri);
      const courseList: Course[] = [];

      for (const subdir of subdirs) {
        const subdirUri = `${folderUri}/${subdir}`;
        const subdirInfo = await FileSystem.getInfoAsync(subdirUri);
        if (!subdirInfo.isDirectory) continue;

        const fileNames = await FileSystem.readDirectoryAsync(subdirUri);
        const courseFiles: CourseFile[] = [];

        for (const fileName of fileNames.sort()) {
          const type = getFileType(fileName);
          if (!type) continue;
          const fileProgress = progressData[subdir]?.[fileName];
          courseFiles.push({
            name: fileName,
            uri: `${subdirUri}/${fileName}`,
            type,
            completed: fileProgress?.completed ?? false,
            watchedSeconds: fileProgress?.watchedSeconds ?? 0,
            durationSeconds: fileProgress?.durationSeconds ?? 0,
          });
        }

        if (courseFiles.length === 0) continue;

        const totalVideos = courseFiles.filter(f => f.type === 'video').length;
        const completedVideos = courseFiles.filter(f => f.type === 'video' && f.completed).length;
        const percentComplete = totalVideos > 0 ? Math.round((completedVideos / totalVideos) * 100) : 0;

        courseList.push({
          id: subdir,
          name: subdir,
          dirUri: subdirUri,
          files: courseFiles,
          totalVideos,
          completedVideos,
          percentComplete,
        });
      }

      setCourses(courseList);
    } catch (e) {
      console.error('Error scanning courses:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const loadCourses = useCallback(async () => {
    const storedProgress = await AsyncStorage.getItem(STORAGE_KEYS.PROGRESS);
    const parsedProgress: ProgressData = storedProgress ? JSON.parse(storedProgress) : {};
    setProgress(parsedProgress);
    await scanCoursesFromStorage(FIXED_ROOT_FOLDER, parsedProgress);
  }, [rootFolderUri]);

  const updateProgress = useCallback(async (
    courseId: string,
    fileName: string,
    watchedSeconds: number,
    durationSeconds: number
  ) => {
    const newProgress = { ...progress };
    if (!newProgress[courseId]) newProgress[courseId] = {};
    const existing = newProgress[courseId][fileName];
    const alreadyComplete = existing?.completed ?? false;

    const pct = durationSeconds > 0 ? watchedSeconds / durationSeconds : 0;
    const completed = alreadyComplete || pct >= 0.9;

    newProgress[courseId][fileName] = {
      completed,
      watchedSeconds,
      durationSeconds,
    };

    setProgress(newProgress);
    await AsyncStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(newProgress));

    setCourses(prev => prev.map(c => {
      if (c.id !== courseId) return c;
      const updatedFiles = c.files.map(f =>
        f.name === fileName
          ? { ...f, completed, watchedSeconds, durationSeconds }
          : f
      );
      const totalVideos = updatedFiles.filter(f => f.type === 'video').length;
      const completedVideos = updatedFiles.filter(f => f.type === 'video' && f.completed).length;
      const percentComplete = totalVideos > 0 ? Math.round((completedVideos / totalVideos) * 100) : 0;
      return { ...c, files: updatedFiles, totalVideos, completedVideos, percentComplete };
    }));
  }, [progress]);

  const markFileComplete = useCallback(async (courseId: string, fileName: string) => {
    const newProgress = { ...progress };
    if (!newProgress[courseId]) newProgress[courseId] = {};
    newProgress[courseId][fileName] = {
      ...newProgress[courseId][fileName],
      completed: true,
    };
    setProgress(newProgress);
    await AsyncStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(newProgress));

    setCourses(prev => prev.map(c => {
      if (c.id !== courseId) return c;
      const updatedFiles = c.files.map(f =>
        f.name === fileName ? { ...f, completed: true } : f
      );
      const totalVideos = updatedFiles.filter(f => f.type === 'video').length;
      const completedVideos = updatedFiles.filter(f => f.type === 'video' && f.completed).length;
      const percentComplete = totalVideos > 0 ? Math.round((completedVideos / totalVideos) * 100) : 0;
      return { ...c, files: updatedFiles, totalVideos, completedVideos, percentComplete };
    }));
  }, [progress]);

  const setResumeState = useCallback(async (state: ResumeState) => {
    setResume(state);
    await AsyncStorage.setItem(STORAGE_KEYS.RESUME, JSON.stringify(state));
  }, []);

  const addStudyMinutes = useCallback(async (minutes: number) => {
    const today = getTodayString();
    setDailyStudy(prev => {
      const current = prev.date === today ? prev.minutesWatched : 0;
      const updated = { date: today, minutesWatched: current + minutes };
      AsyncStorage.setItem(STORAGE_KEYS.DAILY_STUDY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const getCourseById = useCallback((id: string) => {
    return courses.find(c => c.id === id);
  }, [courses]);

  return (
    <CourseContext.Provider value={{
      courses,
      resume,
      dailyStudy,
      rootFolderUri,
      fixedRootFolderUri: FIXED_ROOT_FOLDER,
      isLoading,
      loadCourses,
      updateProgress,
      markFileComplete,
      setResumeState,
      addStudyMinutes,
      getCourseById,
    }}>
      {children}
    </CourseContext.Provider>
  );
}

export function useCourses() {
  const ctx = useContext(CourseContext);
  if (!ctx) throw new Error('useCourses must be used within CourseProvider');
  return ctx;
}
