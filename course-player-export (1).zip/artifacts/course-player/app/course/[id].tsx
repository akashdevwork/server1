import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router, useLocalSearchParams } from 'expo-router';
import React from 'react';
import {
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { CircularProgress } from '@/components/CircularProgress';
import { FileListItem } from '@/components/FileListItem';
import { Colors } from '@/constants/colors';
import { useCourses } from '@/context/CourseContext';

export default function CourseDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getCourseById } = useCourses();
  const course = getCourseById(id);

  if (!course) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={Colors.text} />
        </TouchableOpacity>
        <View style={styles.emptyState}>
          <Feather name="alert-circle" size={40} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>Course not found</Text>
        </View>
      </View>
    );
  }

  const handleFilePress = (fileName: string) => {
    Haptics.selectionAsync();
    router.push({
      pathname: '/player/[courseId]/[fileName]',
      params: { courseId: course.id, fileName },
    });
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 0) }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtnRow}>
          <Feather name="arrow-left" size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.title} numberOfLines={1}>{course.name}</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Progress Banner */}
      <Animated.View entering={FadeIn.duration(300)} style={styles.progressBanner}>
        <View style={styles.bannerTop}>
          <CircularProgress size={72} strokeWidth={5} percent={course.percentComplete} />
          <View style={styles.progressInfo}>
            <Text style={styles.progressLabel}>Course progress</Text>
            <Text style={styles.progressDetail}>
              {course.completedVideos} of {course.totalVideos} videos completed
            </Text>
            <View style={styles.segmentTrack}>
              <View style={[styles.segmentFill, { width: `${course.percentComplete}%` }]} />
            </View>
            {course.percentComplete === 100 && (
              <View style={styles.completedBadge}>
                <Feather name="check-circle" size={12} color={Colors.success} />
                <Text style={styles.completedText}>Completed</Text>
              </View>
            )}
          </View>
        </View>
        <TouchableOpacity
          style={styles.resumeAllBtn}
          activeOpacity={0.75}
          onPress={() => {
            if (course.files[0]) {
              Haptics.selectionAsync();
              router.push({
                pathname: '/player/[courseId]/[fileName]',
                params: { courseId: course.id, fileName: course.files[0].name },
              });
            }
          }}
        >
          <Feather name="play" size={14} color={Colors.textInverse} />
          <Text style={styles.resumeAllText}>Start from first file</Text>
        </TouchableOpacity>
      </Animated.View>

      {/* File list */}
      <FlatList
        data={course.files}
        keyExtractor={item => item.name}
        renderItem={({ item, index }) => (
          <FileListItem
            file={item}
            index={index}
            onPress={() => handleFilePress(item.name)}
          />
        )}
        contentContainerStyle={[
          styles.list,
          { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 20) },
        ]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Feather name="inbox" size={36} color={Colors.textMuted} />
            <Text style={styles.emptyTitle}>No files found</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backBtnRow: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
  },
  backBtn: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 16,
  },
  title: {
    flex: 1,
    fontSize: 18,
    color: Colors.text,
    fontFamily: 'Inter_700Bold',
    textAlign: 'center',
  },
  progressBanner: {
    backgroundColor: Colors.bgCard,
    margin: 16,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  bannerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  progressInfo: {
    flex: 1,
    gap: 4,
  },
  progressLabel: {
    fontSize: 12,
    color: Colors.textMuted,
    fontFamily: 'Inter_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  progressDetail: {
    fontSize: 15,
    color: Colors.text,
    fontFamily: 'Inter_600SemiBold',
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  completedText: {
    fontSize: 12,
    color: Colors.success,
    fontFamily: 'Inter_600SemiBold',
  },
  segmentTrack: {
    height: 6,
    borderRadius: 999,
    backgroundColor: Colors.progressTrack,
    overflow: 'hidden',
    marginTop: 8,
  },
  segmentFill: {
    height: 6,
    borderRadius: 999,
    backgroundColor: Colors.accent,
  },
  resumeAllBtn: {
    marginTop: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.accent,
    borderRadius: 14,
    paddingVertical: 13,
  },
  resumeAllText: {
    fontSize: 14,
    color: Colors.textInverse,
    fontFamily: 'Inter_700Bold',
  },
  list: {
    paddingTop: 8,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    padding: 40,
  },
  emptyTitle: {
    fontSize: 16,
    color: Colors.textSecondary,
    fontFamily: 'Inter_600SemiBold',
  },
});
