import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import {
  ActivityIndicator,
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CourseCard } from '@/components/CourseCard';
import { Colors } from '@/constants/colors';
import { useCourses } from '@/context/CourseContext';

export default function CoursesScreen() {
  const insets = useSafeAreaInsets();
  const { courses, isLoading, loadCourses, rootFolderUri } = useCourses();

  return (
    <View style={[styles.container, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 0) }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>Courses</Text>
        <TouchableOpacity onPress={loadCourses} style={styles.refreshBtn} disabled={isLoading}>
          {isLoading ? (
            <ActivityIndicator size="small" color={Colors.accent} />
          ) : (
            <Feather name="refresh-cw" size={18} color={Colors.textSecondary} />
          )}
        </TouchableOpacity>
      </View>

      {/* Content */}
      {!rootFolderUri ? (
        <Animated.View entering={FadeIn} style={styles.emptyState}>
          <Feather name="folder" size={48} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>No folder selected</Text>
          <Text style={styles.emptyText}>Go back and select your course folder.</Text>
        </Animated.View>
      ) : courses.length === 0 && !isLoading ? (
        <Animated.View entering={FadeIn} style={styles.emptyState}>
          <Feather name="inbox" size={48} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>No courses found</Text>
          <Text style={styles.emptyText}>Add folders with video/PDF files to your course directory.</Text>
        </Animated.View>
      ) : (
        <FlatList
          data={courses}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <CourseCard
              course={item}
              onPress={() => router.push({
                pathname: '/course/[id]',
                params: { id: item.id },
              })}
            />
          )}
          contentContainerStyle={[
            styles.list,
            { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 20) },
          ]}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
  },
  title: {
    flex: 1,
    fontSize: 20,
    color: Colors.text,
    fontFamily: 'Inter_700Bold',
    textAlign: 'center',
  },
  refreshBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
  },
  list: {
    padding: 16,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    padding: 40,
  },
  emptyTitle: {
    fontSize: 18,
    color: Colors.textSecondary,
    fontFamily: 'Inter_600SemiBold',
  },
  emptyText: {
    fontSize: 14,
    color: Colors.textMuted,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    lineHeight: 20,
  },
});
