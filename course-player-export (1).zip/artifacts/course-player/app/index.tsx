import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Animated, { FadeIn, FadeInDown, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { DailyGoalBar } from '@/components/DailyGoalBar';
import { Colors } from '@/constants/colors';
import { useCourses } from '@/context/CourseContext';
import { useNotifications } from '@/hooks/useNotifications';

function formatTime(seconds: number): string {
  if (!seconds || seconds <= 0) return '0:00';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function formatRemaining(watched: number, duration: number): string {
  const rem = Math.max(0, duration - watched);
  return formatTime(rem) + ' left';
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { resume, dailyStudy, courses, isLoading, loadCourses, rootFolderUri, fixedRootFolderUri } = useCourses();
  useNotifications();

  const scale = useSharedValue(1);

  const resumeAnimStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handleResumePress = () => {
    if (!resume) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    scale.value = withSpring(0.96, {}, () => {
      scale.value = withSpring(1);
    });
    router.push({
      pathname: '/player/[courseId]/[fileName]',
      params: { courseId: resume.courseId, fileName: resume.fileName },
    });
  };

  const handleRefresh = async () => {
    Haptics.selectionAsync();
    await loadCourses();
  };

  const totalCompleted = courses.reduce((a, c) => a + c.completedVideos, 0);
  const totalVideos = courses.reduce((a, c) => a + c.totalVideos, 0);

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={[
        styles.scrollContent,
        {
          paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 20),
          paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 20),
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <Animated.View entering={FadeIn.duration(400)} style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good {getGreeting()}</Text>
          <Text style={styles.title}>Your Learning</Text>
        </View>
        <TouchableOpacity
          style={styles.coursesBtn}
          onPress={() => router.push('/courses')}
          activeOpacity={0.7}
        >
          <Feather name="grid" size={16} color={Colors.accent} />
          <Text style={styles.coursesBtnText}>Courses</Text>
        </TouchableOpacity>
      </Animated.View>

      {/* Resume Card */}
      {resume ? (
        <Animated.View entering={FadeInDown.duration(400).delay(100)} style={resumeAnimStyle}>
          <Pressable style={styles.resumeCard} onPress={handleResumePress}>
            <View style={styles.resumeGlow} />
            <View style={styles.resumeTop}>
              <View style={styles.resumeBadge}>
                <Text style={styles.resumeBadgeText}>Continue</Text>
              </View>
              <View style={styles.progressPill}>
                <Text style={styles.progressPillText}>{resume.watchedSeconds > 0 ? formatRemaining(resume.watchedSeconds, resume.durationSeconds) : 'Start'}</Text>
              </View>
            </View>
            <Text style={styles.resumeCourse} numberOfLines={1}>{resume.courseName}</Text>
            <Text style={styles.resumeFile} numberOfLines={2}>
              {resume.fileName.replace(/^\d+[\.\-_\s]+/, '').replace(/\.[^/.]+$/, '')}
            </Text>

            <View style={styles.resumeBottom}>
              <View style={styles.playBtn}>
                <Feather name="play" size={18} color={Colors.textInverse} />
                <Text style={styles.playBtnText}>Resume</Text>
              </View>
            </View>
          </Pressable>
        </Animated.View>
      ) : (
        <Animated.View entering={FadeInDown.duration(400).delay(100)}>
          <View style={styles.emptyResumeCard}>
            <Feather name="play-circle" size={40} color={Colors.textMuted} />
            <Text style={styles.emptyTitle}>No course in progress</Text>
            <Text style={styles.emptySubtitle}>Select a folder to get started</Text>
          </View>
        </Animated.View>
      )}

      {/* Stats row */}
      {courses.length > 0 && (
        <Animated.View entering={FadeInDown.duration(400).delay(180)} style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{courses.length}</Text>
            <Text style={styles.statLabel}>Courses</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{totalCompleted}</Text>
            <Text style={styles.statLabel}>Done</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{totalVideos}</Text>
            <Text style={styles.statLabel}>Total</Text>
          </View>
        </Animated.View>
      )}

      {/* Daily goal */}
      <Animated.View entering={FadeInDown.duration(400).delay(240)} style={styles.section}>
        <DailyGoalBar minutesWatched={dailyStudy.minutesWatched} dailyTarget={20} />
      </Animated.View>

      {/* Fixed folder info */}
      <Animated.View entering={FadeInDown.duration(400).delay(300)}>
        <TouchableOpacity
          style={styles.folderBtn}
          onPress={handleRefresh}
          activeOpacity={0.7}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color={Colors.accent} />
          ) : (
            <Feather name="refresh-cw" size={16} color={Colors.accent} />
          )}
          <Text style={styles.folderBtnText}>
            Refresh Courses
          </Text>
        </TouchableOpacity>
        <Text style={styles.folderPath} numberOfLines={1}>
          {fixedRootFolderUri}
        </Text>
      </Animated.View>
    </ScrollView>
  );
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
}

const styles = StyleSheet.create({
  scroll: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  scrollContent: {
    paddingHorizontal: 20,
    gap: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  greeting: {
    fontSize: 13,
    color: Colors.textMuted,
    fontFamily: 'Inter_400Regular',
  },
  title: {
    fontSize: 28,
    color: Colors.text,
    fontFamily: 'Inter_700Bold',
    marginTop: 2,
  },
  coursesBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.accentGlow,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: Colors.accentDim,
  },
  coursesBtnText: {
    fontSize: 13,
    color: Colors.accent,
    fontFamily: 'Inter_600SemiBold',
  },
  resumeCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
    gap: 8,
  },
  resumeGlow: {
    position: 'absolute',
    top: -40,
    right: -40,
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: Colors.accentGlow,
  },
  resumeTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  resumeBadge: {
    backgroundColor: Colors.accentGlow,
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderWidth: 1,
    borderColor: Colors.accentDim,
  },
  resumeBadgeText: {
    fontSize: 11,
    color: Colors.accent,
    fontFamily: 'Inter_600SemiBold',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  progressPill: {
    backgroundColor: Colors.clayBg,
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: Colors.clayBorder,
  },
  progressPillText: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontFamily: 'Inter_500Medium',
  },
  resumeCourse: {
    fontSize: 12,
    color: Colors.textMuted,
    fontFamily: 'Inter_500Medium',
    marginTop: 4,
  },
  resumeFile: {
    fontSize: 18,
    color: Colors.text,
    fontFamily: 'Inter_700Bold',
    lineHeight: 24,
  },
  resumeBottom: {
    marginTop: 12,
  },
  playBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.accent,
    borderRadius: 12,
    paddingVertical: 13,
    paddingHorizontal: 24,
    gap: 8,
    alignSelf: 'flex-start',
  },
  playBtnText: {
    fontSize: 15,
    color: Colors.textInverse,
    fontFamily: 'Inter_700Bold',
  },
  emptyResumeCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: 20,
    padding: 36,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.border,
    borderStyle: 'dashed',
  },
  emptyTitle: {
    fontSize: 16,
    color: Colors.textSecondary,
    fontFamily: 'Inter_600SemiBold',
    marginTop: 4,
  },
  emptySubtitle: {
    fontSize: 13,
    color: Colors.textMuted,
    fontFamily: 'Inter_400Regular',
  },
  statsRow: {
    flexDirection: 'row',
    backgroundColor: Colors.bgCard,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  statValue: {
    fontSize: 24,
    color: Colors.text,
    fontFamily: 'Inter_700Bold',
  },
  statLabel: {
    fontSize: 11,
    color: Colors.textMuted,
    fontFamily: 'Inter_500Medium',
  },
  statDivider: {
    width: 1,
    backgroundColor: Colors.border,
    marginHorizontal: 8,
  },
  section: {
    backgroundColor: Colors.bgCard,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  folderBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.bgCard,
    borderRadius: 14,
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  folderBtnText: {
    fontSize: 14,
    color: Colors.textSecondary,
    fontFamily: 'Inter_500Medium',
  },
  folderPath: {
    textAlign: 'center',
    fontSize: 11,
    color: Colors.textMuted,
    fontFamily: 'Inter_400Regular',
    marginTop: 6,
  },
});
