import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { VideoPlayer } from '@/components/VideoPlayer';
import { CodeViewer } from '@/components/viewers/CodeViewer';
import { DocxViewer } from '@/components/viewers/DocxViewer';
import { ImageViewer } from '@/components/viewers/ImageViewer';
import { PDFViewer } from '@/components/viewers/PDFViewer';
import { Colors } from '@/constants/colors';
import { CourseFile, useCourses } from '@/context/CourseContext';

export default function PlayerScreen() {
  const insets = useSafeAreaInsets();
  const { courseId, fileName } = useLocalSearchParams<{ courseId: string; fileName: string }>();
  const { getCourseById, updateProgress, setResumeState, addStudyMinutes, markFileComplete } = useCourses();

  const course = getCourseById(courseId);
  const file: CourseFile | undefined = course?.files.find(f => f.name === fileName);
  const [isLandscape, setIsLandscape] = useState(false);

  const cleanName = file?.name.replace(/^\d+[\.\-_\s]+/, '').replace(/\.[^/.]+$/, '') ?? '';

  /* mark non-video files complete on open */
  useEffect(() => {
    if (!file || file.type === 'video') return;
    markFileComplete(courseId, fileName);
    if (course) {
      setResumeState({
        courseId,
        courseName: course.name,
        fileName,
        fileUri: file.uri,
        fileType: file.type,
        watchedSeconds: 0,
        durationSeconds: 0,
      });
    }
  }, []);

  const handleProgress = useCallback(async (currentTime: number, duration: number) => {
    await updateProgress(courseId, fileName, currentTime, duration);
    const pct = currentTime / duration;
    if (pct >= 0.9) {
      await markFileComplete(courseId, fileName);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    if (course && file) {
      await setResumeState({
        courseId,
        courseName: course.name,
        fileName,
        fileUri: file.uri,
        fileType: 'video',
        watchedSeconds: currentTime,
        durationSeconds: duration,
      });
    }
  }, [courseId, fileName, course, file]);

  const handleComplete = useCallback(async () => {
    await markFileComplete(courseId, fileName);
  }, [courseId, fileName]);

  const handleStudyTime = useCallback((minutes: number) => {
    addStudyMinutes(minutes);
  }, []);

  const handleNavigate = useCallback((nextFileName: string) => {
    router.replace({
      pathname: '/player/[courseId]/[fileName]',
      params: { courseId, fileName: nextFileName },
    });
  }, [courseId]);

  if (!course || !file) {
    return (
      <View style={[styles.container, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 0) }]}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.headerBtn}>
            <Feather name="arrow-left" size={22} color={Colors.text} />
          </TouchableOpacity>
        </View>
        <View style={styles.center}>
          <Feather name="alert-circle" size={40} color={Colors.textMuted} />
          <Text style={styles.errorText}>File not found</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: isLandscape ? 0 : insets.top + (Platform.OS === 'web' ? 67 : 0) }]}>
      {/* Header — hidden in landscape */}
      {!isLandscape && (
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.headerBtn}>
            <Feather name="arrow-left" size={22} color={Colors.text} />
          </TouchableOpacity>
          <View style={styles.headerCenter}>
            <Text style={styles.headerCourse} numberOfLines={1}>{course.name}</Text>
            <Text style={styles.headerFile} numberOfLines={1}>{cleanName}</Text>
          </View>
          <View style={{ width: 44 }} />
        </View>
      )}

      {/* Viewer dispatch */}
      <View style={styles.viewerContainer}>
        {file.type === 'video' && (
          <VideoPlayer
            file={file}
            courseId={courseId}
            allFiles={course.files}
            onProgress={handleProgress}
            onComplete={handleComplete}
            onStudyTime={handleStudyTime}
            onNavigate={handleNavigate}
            onLandscapeChange={setIsLandscape}
          />
        )}

        {file.type === 'pdf' && <PDFViewer uri={file.uri} />}
        {file.type === 'image' && <ImageViewer uri={file.uri} name={file.name} />}
        {file.type === 'code' && <CodeViewer uri={file.uri} name={file.name} />}
        {file.type === 'docx' && <DocxViewer uri={file.uri} />}
      </View>

      {/* File info row for non-video types */}
      {file.type !== 'video' && !isLandscape && (
        <View style={[styles.infoRow, { paddingBottom: insets.bottom + 12 }]}>
          <Feather name="check-circle" size={14} color={Colors.success} />
          <Text style={styles.infoText}>Marked as complete</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    gap: 8,
  },
  headerBtn: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 22,
  },
  headerCenter: {
    flex: 1,
    gap: 2,
  },
  headerCourse: {
    fontSize: 11,
    color: Colors.textMuted,
    fontFamily: 'Inter_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  headerFile: {
    fontSize: 14,
    color: Colors.text,
    fontFamily: 'Inter_600SemiBold',
  },
  viewerContainer: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  errorText: {
    color: Colors.textMuted,
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    justifyContent: 'center',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: Colors.borderSubtle,
  },
  infoText: {
    color: Colors.textMuted,
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
  },
});
