export const Colors = {
  bg: '#0A0C10',
  bgCard: '#111318',
  bgElevated: '#181C24',
  bgSurface: '#1E2330',
  border: '#2A2F3E',
  borderSubtle: '#1E2330',

  accent: '#4F8EF7',
  accentDim: '#2C4F8F',
  accentGlow: 'rgba(79, 142, 247, 0.15)',

  success: '#34C759',
  successDim: 'rgba(52, 199, 89, 0.15)',
  warning: '#FF9F0A',
  error: '#FF453A',

  text: '#F0F4FF',
  textSecondary: '#8B93A8',
  textMuted: '#4A5168',
  textInverse: '#0A0C10',

  tabBar: '#0D1017',
  tabBarBorder: '#1A1F2E',

  overlay: 'rgba(0,0,0,0.7)',
  overlayLight: 'rgba(0,0,0,0.4)',

  progressTrack: '#1E2330',
  progressFill: '#4F8EF7',

  clayBg: 'rgba(255,255,255,0.04)',
  clayBorder: 'rgba(255,255,255,0.08)',
  clayShadow: 'rgba(0,0,0,0.5)',
};
