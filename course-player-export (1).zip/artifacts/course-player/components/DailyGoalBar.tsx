import { Feather } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Colors } from '@/constants/colors';

interface Props {
  minutesWatched: number;
  dailyTarget?: number;
}

export function DailyGoalBar({ minutesWatched, dailyTarget = 20 }: Props) {
  const pct = Math.min((minutesWatched / dailyTarget) * 100, 100);
  const done = pct >= 100;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.left}>
          <Feather name={done ? 'zap' : 'clock'} size={13} color={done ? Colors.warning : Colors.textMuted} />
          <Text style={styles.label}>Daily Goal</Text>
        </View>
        <Text style={[styles.count, done && styles.countDone]}>
          {minutesWatched}m / {dailyTarget}m
        </Text>
      </View>
      <View style={styles.track}>
        <View style={[styles.fill, { width: `${pct}%` as any }, done && styles.fillDone]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  label: {
    fontSize: 12,
    color: Colors.textMuted,
    fontFamily: 'Inter_500Medium',
  },
  count: {
    fontSize: 12,
    color: Colors.textSecondary,
    fontFamily: 'Inter_600SemiBold',
  },
  countDone: {
    color: Colors.warning,
  },
  track: {
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.progressTrack,
    overflow: 'hidden',
  },
  fill: {
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.accent,
  },
  fillDone: {
    backgroundColor: Colors.warning,
  },
});
