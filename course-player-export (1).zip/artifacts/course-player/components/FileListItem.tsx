import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Colors } from '@/constants/colors';
import { CourseFile } from '@/context/CourseContext';

interface Props {
  file: CourseFile;
  index: number;
  onPress: () => void;
}

function FileIcon({ type }: { type: CourseFile['type'] }) {
  switch (type) {
    case 'video':
      return <Feather name="play-circle" size={20} color={Colors.accent} />;
    case 'pdf':
      return <MaterialCommunityIcons name="file-pdf-box" size={20} color="#FF6B6B" />;
    case 'image':
      return <Ionicons name="image-outline" size={20} color="#A8E6CF" />;
    case 'code':
      return <MaterialCommunityIcons name="code-braces" size={20} color="#FFD966" />;
    case 'docx':
      return <MaterialCommunityIcons name="file-word" size={20} color="#5B9CF6" />;
    default:
      return <Feather name="file" size={20} color={Colors.textMuted} />;
  }
}

function formatTime(seconds: number): string {
  if (!seconds) return '';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function fileTypeLabel(type: CourseFile['type']): string {
  switch (type) {
    case 'video': return 'Video';
    case 'pdf': return 'PDF';
    case 'image': return 'Image';
    case 'code': return 'Code';
    case 'docx': return 'Document';
    default: return 'File';
  }
}

export function FileListItem({ file, index, onPress }: Props) {
  const cleanName = file.name.replace(/^\d+[\.\-_\s]+/, '').replace(/\.[^/.]+$/, '');
  const remaining = file.type === 'video' && file.durationSeconds && file.watchedSeconds
    ? file.durationSeconds - file.watchedSeconds
    : 0;

  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.indexWrapper}>
        <Text style={styles.index}>{String(index + 1).padStart(2, '0')}</Text>
      </View>

      <View style={styles.iconWrapper}>
        <FileIcon type={file.type} />
      </View>

      <View style={styles.info}>
        <Text style={styles.name} numberOfLines={2}>{cleanName}</Text>
        <View style={styles.metaRow}>
          <Text style={styles.typeBadge}>{fileTypeLabel(file.type)}</Text>
          {file.type === 'video' && remaining > 0 && !file.completed && (
            <Text style={styles.time}>{formatTime(remaining)} left</Text>
          )}
          {file.type === 'video' && file.watchedSeconds && file.watchedSeconds > 0 && !file.completed && (
            <View style={styles.progressPill}>
              <View
                style={[
                  styles.progressPillFill,
                  {
                    width: `${Math.min(100, ((file.watchedSeconds ?? 0) / (file.durationSeconds ?? 1)) * 100)}%` as any,
                  },
                ]}
              />
            </View>
          )}
        </View>
      </View>

      <View style={styles.right}>
        {file.completed ? (
          <View style={styles.completedBadge}>
            <Feather name="check" size={12} color={Colors.success} />
          </View>
        ) : (
          <Feather name="chevron-right" size={18} color={Colors.textMuted} />
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderSubtle,
  },
  indexWrapper: {
    width: 28,
    marginRight: 8,
  },
  index: {
    fontSize: 12,
    color: Colors.textMuted,
    fontFamily: 'Inter_500Medium',
  },
  iconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: Colors.clayBg,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  info: {
    flex: 1,
    gap: 4,
  },
  name: {
    fontSize: 14,
    color: Colors.text,
    fontFamily: 'Inter_500Medium',
    lineHeight: 20,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  typeBadge: {
    fontSize: 10,
    color: Colors.textMuted,
    fontFamily: 'Inter_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  time: {
    fontSize: 11,
    color: Colors.textMuted,
    fontFamily: 'Inter_400Regular',
  },
  progressPill: {
    flex: 1,
    maxWidth: 80,
    height: 3,
    borderRadius: 2,
    backgroundColor: Colors.borderSubtle,
    overflow: 'hidden',
  },
  progressPillFill: {
    height: 3,
    backgroundColor: Colors.accent,
    borderRadius: 2,
  },
  right: {
    marginLeft: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  completedBadge: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: Colors.successDim,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
