import { Feather } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { CircularProgress } from '@/components/CircularProgress';
import { Colors } from '@/constants/colors';
import { Course } from '@/context/CourseContext';

interface Props {
  course: Course;
  onPress: () => void;
}

export function CourseCard({ course, onPress }: Props) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.left}>
        <CircularProgress size={56} strokeWidth={4} percent={course.percentComplete} />
      </View>
      <View style={styles.middle}>
        <Text style={styles.name} numberOfLines={2}>{course.name}</Text>
        <View style={styles.meta}>
          <Feather name="film" size={11} color={Colors.textMuted} />
          <Text style={styles.metaText}>{course.totalVideos} videos</Text>
          <Text style={styles.dot}>·</Text>
          <Text style={styles.metaText}>{course.completedVideos} done</Text>
        </View>
      </View>
      <Feather name="chevron-right" size={18} color={Colors.textMuted} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bgCard,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: 14,
  },
  left: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  middle: {
    flex: 1,
    gap: 6,
  },
  name: {
    fontSize: 15,
    color: Colors.text,
    fontFamily: 'Inter_600SemiBold',
    lineHeight: 20,
  },
  meta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    color: Colors.textMuted,
    fontFamily: 'Inter_400Regular',
  },
  dot: {
    color: Colors.textMuted,
    fontSize: 12,
  },
});
