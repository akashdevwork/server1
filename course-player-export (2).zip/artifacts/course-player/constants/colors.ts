export const Colors = {
  bg: '#0A0C10',
  bgCard: '#111318',
  bgElevated: '#181C24',
  bgSurface: '#1E2330',
  border: '#2A2F3E',
  borderSubtle: '#1E2330',

  accent: '#4F8EF7',
  accentDim: '#2C4F8F',
  accentGlow: 'rgba(79, 142, 247, 0.15)',

  duo: '#58CC02',
  duoDim: 'rgba(88, 204, 2, 0.12)',
  duoBorder: 'rgba(88, 204, 2, 0.35)',

  fire: '#FF9600',
  fireDim: 'rgba(255, 150, 0, 0.12)',
  fireBorder: 'rgba(255, 150, 0, 0.35)',

  gold: '#FFB800',
  goldDim: 'rgba(255, 184, 0, 0.12)',
  goldBorder: 'rgba(255, 184, 0, 0.35)',

  gem: '#CE82FF',
  gemDim: 'rgba(206, 130, 255, 0.12)',

  coral: '#FF6B6B',
  teal: '#00C6AE',

  success: '#58CC02',
  successDim: 'rgba(88, 204, 2, 0.12)',
  warning: '#FF9600',
  error: '#FF453A',

  text: '#F0F4FF',
  textSecondary: '#8B93A8',
  textMuted: '#4A5168',
  textInverse: '#ffffff',

  tabBar: '#0D1017',
  tabBarBorder: '#1A1F2E',

  overlay: 'rgba(0,0,0,0.7)',
  overlayLight: 'rgba(0,0,0,0.4)',

  progressTrack: '#1E2330',
  progressFill: '#4F8EF7',

  clayBg: 'rgba(255,255,255,0.04)',
  clayBorder: 'rgba(255,255,255,0.08)',
  clayShadow: 'rgba(0,0,0,0.5)',
};

export const COURSE_ACCENTS = [
  '#4F8EF7',
  '#58CC02',
  '#FF9600',
  '#CE82FF',
  '#FF6B6B',
  '#00C6AE',
  '#FFB800',
  '#FF4B4B',
];

export function getCourseAccent(name: string): string {
  let hash = 5381;
  for (let i = 0; i < name.length; i++) {
    hash = ((hash << 5) + hash) + name.charCodeAt(i);
    hash = hash & hash;
  }
  return COURSE_ACCENTS[Math.abs(hash) % COURSE_ACCENTS.length];
}
