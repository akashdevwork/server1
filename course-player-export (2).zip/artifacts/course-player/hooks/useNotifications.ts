import { useEffect } from 'react';
import { Platform } from 'react-native';

export function useNotifications() {
  useEffect(() => {
    // Local scheduled notifications require a development build.
    // expo-notifications push functionality is not available in Expo Go on SDK 53+.
    // Notifications are silently skipped here; they work correctly in a production APK build.
    if (Platform.OS !== 'android') return;
    scheduleIfAvailable();
  }, []);
}

async function scheduleIfAvailable() {
  try {
    // Dynamic import so the module is loaded only if the environment supports it.
    // On Expo Go this will throw; we catch and ignore.
    const mod = await import('expo-notifications');
    const { status } = await mod.requestPermissionsAsync();
    if (status !== 'granted') return;

    mod.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: false,
        shouldSetBadge: false,
        shouldShowBanner: true,
        shouldShowList: true,
      }),
    });

    await mod.cancelAllScheduledNotificationsAsync();
    await mod.scheduleNotificationAsync({
      content: {
        title: 'Time to learn',
        body: 'Continue your course and hit your daily goal.',
      },
      trigger: {
        type: mod.SchedulableTriggerInputTypes.DAILY,
        hour: 19,
        minute: 0,
      },
    });
  } catch {
    // Not supported in this environment — ignore silently.
  }
}
