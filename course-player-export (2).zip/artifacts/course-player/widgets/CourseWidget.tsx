import React from 'react';
import {
  FlexWidget,
  TextWidget,
} from 'react-native-android-widget';

interface Props {
  streak: number;
  totalXP: number;
  minutesWatched: number;
  dailyTarget: number;
  courseName?: string;
  fileName?: string;
}

export function CourseWidget({
  streak,
  totalXP,
  minutesWatched,
  dailyTarget,
  courseName,
  fileName,
}: Props) {
  const goalPct = Math.min(100, Math.round((minutesWatched / dailyTarget) * 100));
  const goalDone = goalPct >= 100;

  return (
    <FlexWidget
      style={{
        height: 'match_parent',
        width: 'match_parent',
        flexDirection: 'column',
        backgroundColor: '#111318',
        borderRadius: 20,
        padding: 16,
        justifyContent: 'space-between',
      }}
      clickAction="OPEN_APP"
    >
      {/* Top row: app name + goal badge */}
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <TextWidget
          text="Course Player"
          style={{ fontSize: 13, color: '#4F8EF7', fontWeight: 'bold' }}
        />
        <TextWidget
          text={goalDone ? '  Goal Done!' : `  ${minutesWatched}/${dailyTarget}m`}
          style={{
            fontSize: 11,
            color: goalDone ? '#58CC02' : '#8B93A8',
            fontWeight: 'bold',
          }}
        />
      </FlexWidget>

      {/* Resume title */}
      {courseName ? (
        <FlexWidget style={{ flexDirection: 'column', gap: 2 }}>
          <TextWidget
            text={courseName}
            style={{ fontSize: 10, color: '#4A5168', maxLines: 1 }}
          />
          <TextWidget
            text={fileName ?? ''}
            style={{ fontSize: 13, color: '#F0F4FF', fontWeight: 'bold', maxLines: 1 }}
          />
        </FlexWidget>
      ) : (
        <TextWidget
          text="Tap to start learning"
          style={{ fontSize: 13, color: '#8B93A8' }}
        />
      )}

      {/* Divider */}
      <FlexWidget style={{ height: 1, backgroundColor: '#2A2F3E', width: 'match_parent' }} />

      {/* Stats row */}
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        {/* Streak */}
        <FlexWidget style={{ flexDirection: 'column', alignItems: 'center', gap: 2 }}>
          <TextWidget text={String(streak)} style={{ fontSize: 20, color: '#FF9600', fontWeight: 'bold' }} />
          <TextWidget text="Streak" style={{ fontSize: 10, color: '#4A5168' }} />
        </FlexWidget>

        {/* XP */}
        <FlexWidget style={{ flexDirection: 'column', alignItems: 'center', gap: 2 }}>
          <TextWidget text={String(totalXP)} style={{ fontSize: 20, color: '#FFB800', fontWeight: 'bold' }} />
          <TextWidget text="XP" style={{ fontSize: 10, color: '#4A5168' }} />
        </FlexWidget>

        {/* Daily goal */}
        <FlexWidget style={{ flexDirection: 'column', alignItems: 'center', gap: 2 }}>
          <TextWidget
            text={goalDone ? '✓' : `${goalPct}%`}
            style={{ fontSize: 20, color: goalDone ? '#58CC02' : '#4F8EF7', fontWeight: 'bold' }}
          />
          <TextWidget text="Daily Goal" style={{ fontSize: 10, color: '#4A5168' }} />
        </FlexWidget>
      </FlexWidget>

      {/* Progress bar */}
      <FlexWidget style={{ height: 6, backgroundColor: '#1E2330', borderRadius: 3, width: 'match_parent' }}>
        <FlexWidget
          style={{
            height: 6,
            backgroundColor: goalDone ? '#58CC02' : '#4F8EF7',
            borderRadius: 3,
            width: `${goalPct}%`,
          }}
        />
      </FlexWidget>
    </FlexWidget>
  );
}
