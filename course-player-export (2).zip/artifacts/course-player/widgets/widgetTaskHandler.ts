import AsyncStorage from '@react-native-async-storage/async-storage';
import { AndroidWidget } from 'react-native-android-widget';
import { CourseWidget } from './CourseWidget';

const STORAGE_KEYS = {
  DAILY_STUDY: '@course_daily_study',
  STREAK: '@course_streak',
  TOTAL_XP: '@course_total_xp',
  RESUME: '@course_resume',
};

function getTodayString(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

async function getWidgetData() {
  try {
    const [daily, streak, xp, resume] = await Promise.all([
      AsyncStorage.getItem(STORAGE_KEYS.DAILY_STUDY),
      AsyncStorage.getItem(STORAGE_KEYS.STREAK),
      AsyncStorage.getItem(STORAGE_KEYS.TOTAL_XP),
      AsyncStorage.getItem(STORAGE_KEYS.RESUME),
    ]);

    const today = getTodayString();
    const dailyData = daily ? JSON.parse(daily) : null;
    const minutesWatched = dailyData?.date === today ? (dailyData.minutesWatched ?? 0) : 0;

    const resumeData = resume ? JSON.parse(resume) : null;

    return {
      streak: parseInt(streak ?? '0', 10) || 0,
      totalXP: parseInt(xp ?? '0', 10) || 0,
      minutesWatched,
      courseName: resumeData?.courseName ?? null,
      fileName: resumeData?.fileName
        ? resumeData.fileName.replace(/^\d+[\.\-_\s]+/, '').replace(/\.[^/.]+$/, '')
        : null,
    };
  } catch {
    return { streak: 0, totalXP: 0, minutesWatched: 0, courseName: null, fileName: null };
  }
}

export async function widgetTaskHandler(props: any) {
  const widgetAction = props?.widgetAction ?? '';
  const widgetId = props?.widgetInfo?.widgetId;

  if (!widgetId) return;

  switch (widgetAction) {
    case 'WIDGET_ADDED':
    case 'WIDGET_UPDATE':
    case 'WIDGET_RESIZED':
    case 'OPEN_APP': {
      const data = await getWidgetData();
      await AndroidWidget.renderWidget({
        widgetId,
        name: 'CourseWidget',
        props: {
          ...data,
          dailyTarget: 20,
        },
      });
      break;
    }
    default:
      break;
  }
}

export async function updateAllWidgets() {
  try {
    const data = await getWidgetData();
    await AndroidWidget.updateAllWidgets({
      name: 'CourseWidget',
      props: {
        ...data,
        dailyTarget: 20,
      },
    });
  } catch {
    // Widget not installed or platform not supported
  }
}
