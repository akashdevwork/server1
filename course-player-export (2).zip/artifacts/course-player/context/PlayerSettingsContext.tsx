import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';

export type RepeatMode = 'none' | 'one' | 'all';

interface PlayerSettings {
  speed: number;
  volume: number;
  muted: boolean;
  repeatMode: RepeatMode;
  shuffle: boolean;
  subtitlesEnabled: boolean;
}

interface PlayerSettingsContextType extends PlayerSettings {
  setSpeed: (v: number) => void;
  setVolume: (v: number) => void;
  setMuted: (v: boolean) => void;
  setRepeatMode: (v: RepeatMode) => void;
  setShuffle: (v: boolean) => void;
  setSubtitlesEnabled: (v: boolean) => void;
}

const DEFAULTS: PlayerSettings = {
  speed: 1,
  volume: 1,
  muted: false,
  repeatMode: 'none',
  shuffle: false,
  subtitlesEnabled: true,
};

const KEY = '@player_settings';

const Ctx = createContext<PlayerSettingsContextType | null>(null);

export function PlayerSettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<PlayerSettings>(DEFAULTS);

  useEffect(() => {
    AsyncStorage.getItem(KEY).then(raw => {
      if (raw) {
        try { setSettings(prev => ({ ...prev, ...JSON.parse(raw) })); } catch {}
      }
    });
  }, []);

  const persist = (next: PlayerSettings) => {
    setSettings(next);
    AsyncStorage.setItem(KEY, JSON.stringify(next));
  };

  const setSpeed = useCallback((v: number) => persist({ ...settings, speed: v }), [settings]);
  const setVolume = useCallback((v: number) => persist({ ...settings, volume: v }), [settings]);
  const setMuted = useCallback((v: boolean) => persist({ ...settings, muted: v }), [settings]);
  const setRepeatMode = useCallback((v: RepeatMode) => persist({ ...settings, repeatMode: v }), [settings]);
  const setShuffle = useCallback((v: boolean) => persist({ ...settings, shuffle: v }), [settings]);
  const setSubtitlesEnabled = useCallback((v: boolean) => persist({ ...settings, subtitlesEnabled: v }), [settings]);

  return (
    <Ctx.Provider value={{ ...settings, setSpeed, setVolume, setMuted, setRepeatMode, setShuffle, setSubtitlesEnabled }}>
      {children}
    </Ctx.Provider>
  );
}

export function usePlayerSettings() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('usePlayerSettings must be within PlayerSettingsProvider');
  return ctx;
}
