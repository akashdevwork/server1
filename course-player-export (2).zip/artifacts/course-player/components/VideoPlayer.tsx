import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Brightness from 'expo-brightness';
import * as FileSystem from 'expo-file-system/legacy';
import * as Haptics from 'expo-haptics';
import * as ScreenOrientation from 'expo-screen-orientation';
import { useVideoPlayer, VideoView } from 'expo-video';
import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import {
  Dimensions,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  clamp,
  FadeIn,
  FadeOut,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { Colors } from '@/constants/colors';
import { CourseFile } from '@/context/CourseContext';
import { RepeatMode, usePlayerSettings } from '@/context/PlayerSettingsContext';

/* ─── types ──────────────────────────────────────────────────────────────── */
interface SubCue {
  start: number;
  end: number;
  text: string;
}

interface Props {
  file: CourseFile;
  courseId: string;
  allFiles: CourseFile[];
  onProgress: (current: number, duration: number) => void;
  onComplete: () => void;
  onStudyTime: (minutes: number) => void;
  onNavigate: (fileName: string) => void;
  onLandscapeChange?: (landscape: boolean) => void;
}

/* ─── helpers ────────────────────────────────────────────────────────────── */
function fmt(s: number) {
  if (!s || isNaN(s)) return '0:00';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = Math.floor(s % 60);
  if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
  return `${m}:${String(ss).padStart(2,'0')}`;
}

function parseSRTTime(t: string): number {
  const [hms, ms] = t.split(',');
  const [h, m, s] = hms.split(':').map(Number);
  return h * 3600 + m * 60 + s + Number(ms) / 1000;
}

function parseSRT(raw: string): SubCue[] {
  const cues: SubCue[] = [];
  const blocks = raw.trim().split(/\r?\n\r?\n/);
  for (const block of blocks) {
    const lines = block.trim().split(/\r?\n/);
    if (lines.length < 3) continue;
    const timeLine = lines[1];
    const m = timeLine.match(/(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})/);
    if (!m) continue;
    cues.push({ start: parseSRTTime(m[1]), end: parseSRTTime(m[2]), text: lines.slice(2).join('\n') });
  }
  return cues;
}

function parseVTTTime(t: string): number {
  const parts = t.split(':');
  if (parts.length === 3) {
    const [h, m, s] = parts;
    return Number(h) * 3600 + Number(m) * 60 + parseFloat(s.replace(',','.'));
  }
  const [m, s] = parts;
  return Number(m) * 60 + parseFloat(s.replace(',','.'));
}

function parseVTT(raw: string): SubCue[] {
  const cues: SubCue[] = [];
  const blocks = raw.trim().split(/\r?\n\r?\n/);
  for (const block of blocks) {
    const lines = block.trim().split(/\r?\n/);
    const timeLine = lines.find(l => l.includes('-->'));
    if (!timeLine) continue;
    const m = timeLine.match(/(\d{1,2}:\d{2}[:.]\d{2,3}(?:[,.]\d+)?) --> (\d{1,2}:\d{2}[:.]\d{2,3}(?:[,.]\d+)?)/);
    if (!m) continue;
    const textIdx = lines.indexOf(timeLine) + 1;
    const text = lines.slice(textIdx).join('\n').replace(/<[^>]+>/g, '').trim();
    if (text) cues.push({ start: parseVTTTime(m[1]), end: parseVTTTime(m[2]), text });
  }
  return cues;
}

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2] as const;
const REPEAT_ICONS: Record<RepeatMode, any> = { none: 'repeat', one: 'repeat-once', all: 'repeat' };

/* ─── Seek Bar ───────────────────────────────────────────────────────────── */
function SeekBar({
  progress, onSeekStart, onSeekChange, onSeekEnd,
}: {
  progress: number;
  onSeekStart: () => void;
  onSeekChange: (p: number) => void;
  onSeekEnd: (p: number) => void;
}) {
  const barWidth = useSharedValue(0);
  const dragging = useSharedValue(false);
  const dragProgress = useSharedValue(progress);
  const thumbScale = useSharedValue(1);

  const displayProgress = dragging.value ? dragProgress.value : progress;

  const pan = Gesture.Pan()
    .minDistance(1)
    .onStart(() => {
      dragging.value = true;
      thumbScale.value = withSpring(1.6, { damping: 12 });
      runOnJS(onSeekStart)();
    })
    .onUpdate((e) => {
      if (barWidth.value === 0) return;
      const p = clamp(e.x / barWidth.value, 0, 1);
      dragProgress.value = p;
      runOnJS(onSeekChange)(p);
    })
    .onEnd(() => {
      const finalP = dragProgress.value;
      dragging.value = false;
      thumbScale.value = withSpring(1, { damping: 12 });
      runOnJS(onSeekEnd)(finalP);
    });

  const tap = Gesture.Tap()
    .onEnd((e) => {
      if (barWidth.value === 0) return;
      const p = clamp(e.x / barWidth.value, 0, 1);
      runOnJS(onSeekEnd)(p);
    });

  const fillStyle = useAnimatedStyle(() => ({ width: `${(dragging.value ? dragProgress.value : progress) * 100}%` as any }));
  const thumbStyle = useAnimatedStyle(() => ({
    left: `${(dragging.value ? dragProgress.value : progress) * 100}%` as any,
    transform: [{ scale: thumbScale.value }],
  }));

  return (
    <GestureDetector gesture={Gesture.Simultaneous(tap, pan)}>
      <View
        style={seekStyles.track}
        onLayout={(e) => { barWidth.value = e.nativeEvent.layout.width; }}
      >
        <View style={seekStyles.fill}>
          <Animated.View style={[seekStyles.played, fillStyle]} />
        </View>
        <Animated.View style={[seekStyles.thumb, thumbStyle]} />
      </View>
    </GestureDetector>
  );
}

const seekStyles = StyleSheet.create({
  track: {
    flex: 1,
    height: 20,
    justifyContent: 'center',
    position: 'relative',
  },
  fill: {
    height: 3,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.25)',
    overflow: 'visible',
    position: 'relative',
  },
  played: {
    height: 3,
    backgroundColor: Colors.accent,
    borderRadius: 3,
  },
  thumb: {
    position: 'absolute',
    width: 13,
    height: 13,
    borderRadius: 7,
    backgroundColor: '#fff',
    marginLeft: -6.5,
    top: '50%',
    marginTop: -6.5,
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 4,
  },
});

/* ─── Level Indicator ─────────────────────────────────────────────────────── */
function LevelIndicator({ icon, label, level, visible }: {
  icon: string; label: string; level: number; visible: boolean;
}) {
  if (!visible) return null;
  return (
    <Animated.View entering={FadeIn.duration(120)} exiting={FadeOut.duration(200)} style={lvlStyles.container}>
      <Feather name={icon as any} size={18} color="#fff" />
      <Text style={lvlStyles.label}>{label}</Text>
      <View style={lvlStyles.bar}>
        <View style={[lvlStyles.barFill, { width: `${level * 100}%` as any }]} />
      </View>
      <Text style={lvlStyles.pct}>{Math.round(level * 100)}%</Text>
    </Animated.View>
  );
}

const lvlStyles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '30%',
    alignSelf: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 10,
    alignItems: 'center',
    gap: 6,
    minWidth: 120,
  },
  label: { color: '#fff', fontSize: 12, fontFamily: 'Inter_500Medium' },
  bar: { width: 100, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.3)', overflow: 'hidden' },
  barFill: { height: 4, backgroundColor: '#fff', borderRadius: 2 },
  pct: { color: 'rgba(255,255,255,0.7)', fontSize: 11, fontFamily: 'Inter_400Regular' },
});

/* ─── Seek Flash ──────────────────────────────────────────────────────────── */
function SeekFlash({ direction, amount }: { direction: 'left' | 'right' | null; amount: number }) {
  if (!direction) return null;
  return (
    <Animated.View
      entering={FadeIn.duration(80)}
      exiting={FadeOut.duration(300)}
      style={[flashStyles.container, direction === 'left' ? flashStyles.left : flashStyles.right]}
    >
      <Feather name={direction === 'left' ? 'rotate-ccw' : 'rotate-cw'} size={26} color="white" />
      <Text style={flashStyles.text}>{amount}s</Text>
    </Animated.View>
  );
}

const flashStyles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '30%',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 50,
    paddingHorizontal: 18,
    paddingVertical: 14,
    alignItems: 'center',
    gap: 4,
  },
  left: { left: 20 },
  right: { right: 20 },
  text: { color: '#fff', fontSize: 12, fontFamily: 'Inter_700Bold' },
});

/* ─── Main VideoPlayer ─────────────────────────────────────────────────────── */
export function VideoPlayer({
  file,
  courseId,
  allFiles,
  onProgress,
  onComplete,
  onStudyTime,
  onNavigate,
  onLandscapeChange,
}: Props) {
  const settings = usePlayerSettings();
  const { width: W, height: H } = Dimensions.get('window');
  const isWeb = Platform.OS === 'web';

  /* ── player ── */
  const player = useVideoPlayer(file.uri, (p) => {
    p.playbackRate = settings.speed;
    p.volume = settings.volume;
    p.muted = settings.muted;
    if (file.watchedSeconds && file.watchedSeconds > 5) {
      p.currentTime = file.watchedSeconds;
    }
    p.play();
  });

  /* ── state ── */
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(file.watchedSeconds ?? 0);
  const [duration, setDuration] = useState(file.durationSeconds ?? 0);
  const [showControls, setShowControls] = useState(true);
  const [isLocked, setIsLocked] = useState(false);
  const [isLandscape, setIsLandscape] = useState(false);
  const [speedIdx, setSpeedIdx] = useState(SPEEDS.indexOf(settings.speed as any) >= 0 ? SPEEDS.indexOf(settings.speed as any) : 2);
  const [seekFlash, setSeekFlash] = useState<{ direction: 'left' | 'right'; amount: number } | null>(null);
  const [volumeVis, setVolumeVis] = useState(false);
  const [brightnessVis, setBrightnessVis] = useState(false);
  const [volumeLevel, setVolumeLevel] = useState(settings.volume);
  const [brightnessLevel, setBrightnessLevel] = useState(0.5);
  const [subtitles, setSubtitles] = useState<SubCue[]>([]);
  const [currentSub, setCurrentSub] = useState<string | null>(null);
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekPreview, setSeekPreview] = useState(0);
  const [autoNextCountdown, setAutoNextCountdown] = useState<number | null>(null);
  const [isBuffering, setIsBuffering] = useState(false);

  /* ── refs ── */
  const controlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const studyStart = useRef<number | null>(null);
  const saveTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const panStart = useRef({ x: 0, y: 0 });
  const panMode = useRef<'seek' | 'volume' | 'brightness' | null>(null);
  const panBaseTime = useRef(0);
  const panBaseVol = useRef(settings.volume);
  const panBaseBrightness = useRef(0.5);
  const flashTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const volumeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const brightnessTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  /* ── scale shared value for pinch zoom ── */
  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const scaleStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  /* ── subtitle loader ── */
  useEffect(() => {
    if (isWeb) return;
    (async () => {
      try {
        const base = (file.uri.startsWith('file://') ? file.uri : `file://${file.uri}`).replace(/\.[^/.]+$/, '');
        const srtUri = base + '.srt';
        const srtInfo = await FileSystem.getInfoAsync(srtUri);
        if (srtInfo.exists) {
          const raw = await FileSystem.readAsStringAsync(srtUri, { encoding: FileSystem.EncodingType.UTF8 });
          setSubtitles(parseSRT(raw));
          return;
        }
        const vttUri = base + '.vtt';
        const vttInfo = await FileSystem.getInfoAsync(vttUri);
        if (vttInfo.exists) {
          const raw = await FileSystem.readAsStringAsync(vttUri, { encoding: FileSystem.EncodingType.UTF8 });
          setSubtitles(parseVTT(raw));
        }
      } catch {}
    })();
  }, [file.uri]);

  /* ── initial brightness ── */
  useEffect(() => {
    if (isWeb) return;
    Brightness.getBrightnessAsync().then(b => {
      setBrightnessLevel(b);
      panBaseBrightness.current = b;
    }).catch(() => {});
  }, []);

  /* ── player listeners ── */
  useEffect(() => {
    if (!player) return;
    const s1 = player.addListener('playingChange', ({ isPlaying: p }) => {
      setIsPlaying(p);
      if (p) { studyStart.current = Date.now(); setIsBuffering(false); }
      else {
        if (studyStart.current) {
          onStudyTime((Date.now() - studyStart.current) / 60000);
          studyStart.current = null;
        }
      }
    });
    const s2 = player.addListener('timeUpdate', ({ currentTime: ct }) => {
      setCurrentTime(ct);
      if (subtitles.length > 0 && settings.subtitlesEnabled) {
        const cue = subtitles.find(c => ct >= c.start && ct <= c.end);
        setCurrentSub(cue?.text ?? null);
      } else {
        setCurrentSub(null);
      }
    });
    const s3 = player.addListener('statusChange', ({ status }) => {
      if (status === 'readyToPlay') {
        setDuration(player.duration ?? 0);
        setIsBuffering(false);
      } else if (status === 'loading') {
        setIsBuffering(true);
      }
    });
    const s4 = player.addListener('playToEnd', () => {
      if (settings.repeatMode === 'one') {
        player.currentTime = 0;
        player.play();
      } else {
        handleVideoEnd();
      }
    });
    return () => { s1.remove(); s2.remove(); s3.remove(); s4.remove(); };
  }, [player, subtitles, settings.repeatMode, settings.subtitlesEnabled]);

  /* ── save progress ── */
  useEffect(() => {
    saveTimer.current = setInterval(() => {
      if (player && player.currentTime > 0 && player.duration > 0) {
        onProgress(player.currentTime, player.duration);
      }
    }, 5000);
    return () => { if (saveTimer.current) clearInterval(saveTimer.current); };
  }, [player]);

  /* ── cleanup ── */
  useEffect(() => {
    return () => {
      if (studyStart.current) {
        onStudyTime((Date.now() - studyStart.current) / 60000);
      }
      if (!isWeb) {
        ScreenOrientation.unlockAsync().catch(() => {});
      }
    };
  }, []);

  /* ── video ended handler ── */
  const handleVideoEnd = useCallback(() => {
    onComplete();
    const shuffledFiles = settings.shuffle ? [...allFiles].sort(() => Math.random() - 0.5) : allFiles;
    const currentIdx = shuffledFiles.findIndex(f => f.name === file.name);
    const nextFile = shuffledFiles[currentIdx + 1] ?? (settings.repeatMode === 'all' ? shuffledFiles[0] : null);
    if (!nextFile) return;
    let count = 5;
    setAutoNextCountdown(count);
    const interval = setInterval(() => {
      count--;
      if (count <= 0) {
        clearInterval(interval);
        setAutoNextCountdown(null);
        onNavigate(nextFile.name);
      } else {
        setAutoNextCountdown(count);
      }
    }, 1000);
  }, [allFiles, file, settings, onComplete, onNavigate]);

  /* ── controls ── */
  const resetControlsTimer = useCallback(() => {
    if (controlsTimer.current) clearTimeout(controlsTimer.current);
    setShowControls(true);
    controlsTimer.current = setTimeout(() => setShowControls(false), 3500);
  }, []);

  const toggleControls = useCallback(() => {
    if (isLocked) return;
    setShowControls(prev => {
      if (!prev) {
        resetControlsTimer();
        return true;
      } else {
        if (controlsTimer.current) clearTimeout(controlsTimer.current);
        return false;
      }
    });
  }, [isLocked]);

  /* ── actions ── */
  const togglePlay = useCallback(() => {
    if (!player) return;
    Haptics.selectionAsync();
    if (player.playing) player.pause();
    else player.play();
    resetControlsTimer();
  }, [player]);

  const seekBy = useCallback((secs: number) => {
    if (!player) return;
    player.currentTime = clampTime(player.currentTime + secs, 0, player.duration ?? 0);
    resetControlsTimer();
  }, [player]);

  function clampTime(v: number, min: number, max: number) {
    return Math.max(min, Math.min(v, max));
  }

  const cycleSpeed = useCallback(() => {
    const next = (speedIdx + 1) % SPEEDS.length;
    setSpeedIdx(next);
    if (player) player.playbackRate = SPEEDS[next];
    settings.setSpeed(SPEEDS[next]);
    Haptics.selectionAsync();
    resetControlsTimer();
  }, [speedIdx, player, settings]);

  const cycleRepeat = useCallback(() => {
    const modes: RepeatMode[] = ['none', 'one', 'all'];
    const next = modes[(modes.indexOf(settings.repeatMode) + 1) % modes.length];
    settings.setRepeatMode(next);
    Haptics.selectionAsync();
  }, [settings]);

  const toggleLandscape = useCallback(async () => {
    if (isWeb) return;
    const next = !isLandscape;
    setIsLandscape(next);
    onLandscapeChange?.(next);
    if (next) {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE);
    } else {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    }
  }, [isLandscape, onLandscapeChange]);

  const goNext = useCallback(() => {
    const files = settings.shuffle ? [...allFiles].sort(() => Math.random() - 0.5) : allFiles;
    const idx = files.findIndex(f => f.name === file.name);
    const nxt = files[idx + 1];
    if (nxt) { setAutoNextCountdown(null); onNavigate(nxt.name); }
  }, [allFiles, file, settings.shuffle, onNavigate]);

  const goPrev = useCallback(() => {
    const idx = allFiles.findIndex(f => f.name === file.name);
    const prv = allFiles[idx - 1];
    if (prv) onNavigate(prv.name);
  }, [allFiles, file, onNavigate]);

  const showSeekFlash = useCallback((dir: 'left' | 'right', amount: number) => {
    if (flashTimer.current) clearTimeout(flashTimer.current);
    setSeekFlash({ direction: dir, amount });
    flashTimer.current = setTimeout(() => setSeekFlash(null), 700);
  }, []);

  /* ── gesture handlers (JS thread) ── */
  const handleDoubleTap = useCallback((x: number) => {
    if (isLocked) return;
    const sw = Dimensions.get('window').width;
    const isLeft = x < sw / 2;
    const amount = 10;
    seekBy(isLeft ? -amount : amount);
    showSeekFlash(isLeft ? 'left' : 'right', amount);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }, [isLocked, seekBy, showSeekFlash]);

  const handlePanStart = useCallback((x: number, y: number) => {
    if (isLocked) return;
    panStart.current = { x, y };
    panMode.current = null;
    panBaseTime.current = player?.currentTime ?? 0;
    panBaseVol.current = volumeLevel;
    panBaseBrightness.current = brightnessLevel;
  }, [isLocked, player, volumeLevel, brightnessLevel]);

  const handlePanUpdate = useCallback((translationX: number, translationY: number, x: number) => {
    if (isLocked) return;
    const sw = Dimensions.get('window').width;
    const sh = Dimensions.get('window').height;

    if (!panMode.current) {
      if (Math.abs(translationX) > Math.abs(translationY) + 8) {
        panMode.current = 'seek';
      } else if (Math.abs(translationY) > Math.abs(translationX) + 8) {
        panMode.current = x < sw / 2 ? 'brightness' : 'volume';
      }
    }

    if (panMode.current === 'seek') {
      if (!player || !player.duration) return;
      const seekDelta = (translationX / sw) * player.duration * 0.7;
      const newTime = clampTime(panBaseTime.current + seekDelta, 0, player.duration);
      player.currentTime = newTime;
      setCurrentTime(newTime);
    } else if (panMode.current === 'volume') {
      const delta = -translationY / sh;
      const newVol = clampTime(panBaseVol.current + delta, 0, 1);
      setVolumeLevel(newVol);
      if (player) player.volume = newVol;
      settings.setVolume(newVol);
      setVolumeVis(true);
      if (volumeTimer.current) clearTimeout(volumeTimer.current);
      volumeTimer.current = setTimeout(() => setVolumeVis(false), 1200);
    } else if (panMode.current === 'brightness') {
      const delta = -translationY / sh;
      const newBrightness = clampTime(panBaseBrightness.current + delta, 0, 1);
      setBrightnessLevel(newBrightness);
      if (!isWeb) Brightness.setBrightnessAsync(newBrightness).catch(() => {});
      setBrightnessVis(true);
      if (brightnessTimer.current) clearTimeout(brightnessTimer.current);
      brightnessTimer.current = setTimeout(() => setBrightnessVis(false), 1200);
    }
  }, [isLocked, player, settings]);

  const handlePanEnd = useCallback(() => {
    panMode.current = null;
  }, []);

  /* ── gestures ── */
  const singleTap = Gesture.Tap()
    .runOnJS(true)
    .onEnd(() => { toggleControls(); });

  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .runOnJS(true)
    .onEnd((e) => { handleDoubleTap(e.x); });

  const panGesture = Gesture.Pan()
    .minDistance(8)
    .runOnJS(true)
    .onStart((e) => { handlePanStart(e.x, e.y); })
    .onUpdate((e) => { handlePanUpdate(e.translationX, e.translationY, e.x); })
    .onEnd(() => { handlePanEnd(); });

  const pinchGesture = Gesture.Pinch()
    .onStart(() => { savedScale.value = scale.value; })
    .onUpdate((e) => { scale.value = clamp(savedScale.value * e.scale, 1, 3); })
    .onEnd(() => {
      savedScale.value = scale.value;
      if (scale.value < 1.1) {
        scale.value = withSpring(1, { damping: 18 });
        savedScale.value = 1;
      }
    });

  const composedGesture = Gesture.Simultaneous(
    Gesture.Exclusive(doubleTap, singleTap),
    panGesture,
    pinchGesture,
  );

  /* ── seekbar handlers ── */
  const handleSeekStart = useCallback(() => { setIsSeeking(true); player?.pause(); }, [player]);
  const handleSeekChange = useCallback((p: number) => { setSeekPreview(p); }, []);
  const handleSeekEnd = useCallback((p: number) => {
    if (player && player.duration) {
      const t = p * player.duration;
      player.currentTime = t;
      setCurrentTime(t);
    }
    setIsSeeking(false);
    if (player) player.play();
  }, [player]);

  /* ── layout ── */
  const progress = duration > 0 ? (isSeeking ? seekPreview : currentTime / duration) : 0;
  const fileIdx = allFiles.findIndex(f => f.name === file.name);
  const hasPrev = fileIdx > 0;
  const hasNext = fileIdx < allFiles.length - 1;

  const VIDEO_H = isLandscape ? H : (W * 9 / 16);
  const videoContainerStyle = isLandscape
    ? { flex: 1, backgroundColor: '#000' }
    : { width: W, height: VIDEO_H, backgroundColor: '#000' };

  return (
    <View style={videoContainerStyle}>
      {/* Scaled video view */}
      <Animated.View style={[StyleSheet.absoluteFill, scaleStyle]}>
        <VideoView
          player={player}
          style={StyleSheet.absoluteFill}
          contentFit="contain"
          nativeControls={false}
          allowsFullscreen={false}
          allowsPictureInPicture={!isWeb}
        />
      </Animated.View>

      {/* Buffering indicator */}
      {isBuffering && (
        <View style={styles.bufferingOverlay} pointerEvents="none">
          <View style={styles.bufferingSpinner} />
        </View>
      )}

      {/* Gesture layer */}
      <GestureDetector gesture={composedGesture}>
        <View style={StyleSheet.absoluteFill}>
          {/* Lock screen mode */}
          {isLocked ? (
            <View style={styles.lockedOverlay}>
              <TouchableOpacity
                style={styles.lockBtn}
                onPress={() => { setIsLocked(false); Haptics.selectionAsync(); }}
              >
                <Feather name="lock" size={20} color="#fff" />
                <Text style={styles.lockText}>Tap to unlock</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              {/* Seek flash indicators */}
              {seekFlash && <SeekFlash direction={seekFlash.direction} amount={seekFlash.amount} />}

              {/* Volume / Brightness indicators */}
              <LevelIndicator
                icon="volume-2"
                label="Volume"
                level={volumeLevel}
                visible={volumeVis}
              />
              <LevelIndicator
                icon="sun"
                label="Brightness"
                level={brightnessLevel}
                visible={brightnessVis}
              />

              {/* Subtitle overlay */}
              {currentSub && settings.subtitlesEnabled && (
                <View style={styles.subtitleContainer} pointerEvents="none">
                  <Text style={styles.subtitleText}>{currentSub}</Text>
                </View>
              )}

              {/* Controls overlay */}
              {showControls && (
                <Animated.View
                  entering={FadeIn.duration(150)}
                  exiting={FadeOut.duration(200)}
                  style={styles.controlsOverlay}
                >
                  {/* Top bar */}
                  <View style={styles.topBar}>
                    <TouchableOpacity
                      style={styles.iconBtn}
                      onPress={() => { setIsLocked(true); Haptics.selectionAsync(); }}
                    >
                      <Feather name="lock" size={18} color="rgba(255,255,255,0.8)" />
                    </TouchableOpacity>
                    <View style={{ flex: 1 }} />
                    <TouchableOpacity
                      style={styles.iconBtn}
                      onPress={() => { settings.setSubtitlesEnabled(!settings.subtitlesEnabled); Haptics.selectionAsync(); }}
                    >
                      <MaterialCommunityIcons
                        name="subtitles"
                        size={20}
                        color={settings.subtitlesEnabled && subtitles.length > 0 ? Colors.accent : 'rgba(255,255,255,0.5)'}
                      />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.iconBtn} onPress={cycleRepeat}>
                      <MaterialCommunityIcons
                        name={REPEAT_ICONS[settings.repeatMode]}
                        size={20}
                        color={settings.repeatMode !== 'none' ? Colors.accent : 'rgba(255,255,255,0.7)'}
                      />
                      {settings.repeatMode === 'one' && (
                        <View style={styles.repeatOneDot} />
                      )}
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.iconBtn}
                      onPress={() => { settings.setShuffle(!settings.shuffle); Haptics.selectionAsync(); }}
                    >
                      <Feather
                        name="shuffle"
                        size={18}
                        color={settings.shuffle ? Colors.accent : 'rgba(255,255,255,0.7)'}
                      />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.iconBtn} onPress={toggleLandscape}>
                      <Feather
                        name={isLandscape ? 'minimize-2' : 'maximize-2'}
                        size={18}
                        color="rgba(255,255,255,0.8)"
                      />
                    </TouchableOpacity>
                  </View>

                  {/* Center controls */}
                  <View style={styles.centerControls}>
                    <TouchableOpacity
                      style={[styles.ctrlBtn, !hasPrev && styles.ctrlBtnDisabled]}
                      onPress={hasPrev ? goPrev : undefined}
                    >
                      <Feather name="skip-back" size={24} color={hasPrev ? '#fff' : 'rgba(255,255,255,0.3)'} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.playBtn} onPress={togglePlay}>
                      <Feather name={isPlaying ? 'pause' : 'play'} size={30} color="#fff" />
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={[styles.ctrlBtn, !hasNext && styles.ctrlBtnDisabled]}
                      onPress={hasNext ? goNext : undefined}
                    >
                      <Feather name="skip-forward" size={24} color={hasNext ? '#fff' : 'rgba(255,255,255,0.3)'} />
                    </TouchableOpacity>
                  </View>

                  {/* Bottom bar */}
                  <View style={styles.bottomBar}>
                    <Text style={styles.timeText}>{fmt(isSeeking ? seekPreview * duration : currentTime)}</Text>
                    <SeekBar
                      progress={progress}
                      onSeekStart={handleSeekStart}
                      onSeekChange={handleSeekChange}
                      onSeekEnd={handleSeekEnd}
                    />
                    <Text style={styles.timeText}>{fmt(duration)}</Text>
                    <TouchableOpacity style={styles.speedBtn} onPress={cycleSpeed}>
                      <Text style={styles.speedText}>{SPEEDS[speedIdx]}×</Text>
                    </TouchableOpacity>
                  </View>
                </Animated.View>
              )}

              {/* Auto-next countdown */}
              {autoNextCountdown !== null && (
                <Animated.View entering={FadeIn.duration(200)} style={styles.autoNextOverlay}>
                  <Text style={styles.autoNextText}>Next video in {autoNextCountdown}s</Text>
                  <TouchableOpacity
                    style={styles.autoNextCancel}
                    onPress={() => setAutoNextCountdown(null)}
                  >
                    <Text style={styles.autoNextCancelText}>Cancel</Text>
                  </TouchableOpacity>
                </Animated.View>
              )}
            </>
          )}
        </View>
      </GestureDetector>
    </View>
  );
}

const styles = StyleSheet.create({
  bufferingOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bufferingSpinner: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.3)',
    borderTopColor: '#fff',
  },
  lockedOverlay: {
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingLeft: 20,
  },
  lockBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(0,0,0,0.55)',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  lockText: { color: '#fff', fontSize: 13, fontFamily: 'Inter_500Medium' },
  controlsOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.42)',
    justifyContent: 'space-between',
    paddingTop: 6,
    paddingBottom: 10,
    paddingHorizontal: 12,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 4,
  },
  iconBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerControls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 28,
  },
  ctrlBtn: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ctrlBtnDisabled: { backgroundColor: 'transparent' },
  playBtn: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(255,255,255,0.18)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 4,
  },
  timeText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
    minWidth: 36,
    textAlign: 'center',
  },
  speedBtn: {
    backgroundColor: 'rgba(255,255,255,0.18)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
    minWidth: 38,
    alignItems: 'center',
  },
  speedText: {
    color: '#fff',
    fontSize: 12,
    fontFamily: 'Inter_700Bold',
  },
  subtitleContainer: {
    position: 'absolute',
    bottom: 48,
    left: 16,
    right: 16,
    alignItems: 'center',
  },
  subtitleText: {
    color: '#fff',
    fontSize: 15,
    fontFamily: 'Inter_500Medium',
    textAlign: 'center',
    textShadowColor: '#000',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 4,
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderRadius: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    overflow: 'hidden',
  },
  repeatOneDot: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: Colors.accent,
  },
  autoNextOverlay: {
    position: 'absolute',
    bottom: 56,
    right: 12,
    backgroundColor: 'rgba(0,0,0,0.72)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 10,
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  autoNextText: {
    color: '#fff',
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
  autoNextCancel: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 8,
  },
  autoNextCancelText: {
    color: Colors.accent,
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
  },
});
