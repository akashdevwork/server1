import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Colors, getCourseAccent } from '@/constants/colors';
import { Course } from '@/context/CourseContext';

interface Props {
  course: Course;
  onPress: () => void;
}

function getInitials(name: string): string {
  const words = name.replace(/[-_]/g, ' ').split(' ').filter(Boolean);
  if (words.length >= 2) return (words[0][0] + words[1][0]).toUpperCase();
  return name.slice(0, 2).toUpperCase();
}

export function CourseCard({ course, onPress }: Props) {
  const accent = getCourseAccent(course.name);
  const pct = course.percentComplete;
  const totalFiles = course.files.length;
  const completedFiles = course.files.filter(f => f.completed).length;
  const isDone = pct === 100;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.75}>
      <View style={[styles.accentBar, { backgroundColor: accent }]} />
      <View style={styles.avatar}>
        <Text style={[styles.avatarText, { color: accent }]}>{getInitials(course.name)}</Text>
      </View>
      <View style={styles.middle}>
        <Text style={styles.name} numberOfLines={2}>{course.name}</Text>
        <Text style={styles.meta}>{completedFiles} / {totalFiles} lessons</Text>
        <View style={styles.barTrack}>
          <View style={[styles.barFill, { width: `${pct}%` as any, backgroundColor: accent }]} />
        </View>
      </View>
      <View style={styles.right}>
        {isDone ? (
          <View style={[styles.doneBadge, { backgroundColor: `${accent}20`, borderColor: `${accent}50` }]}>
            <Text style={{ fontSize: 16 }}>🏆</Text>
          </View>
        ) : (
          <View style={styles.pctWrapper}>
            <Text style={[styles.pct, { color: accent }]}>{pct}%</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bgCard,
    borderRadius: 18,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
    gap: 14,
    paddingRight: 16,
    paddingVertical: 16,
  },
  accentBar: {
    width: 4,
    alignSelf: 'stretch',
    borderRadius: 4,
    marginLeft: 0,
  },
  avatar: {
    width: 46,
    height: 46,
    borderRadius: 14,
    backgroundColor: Colors.bgSurface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 16,
    fontFamily: 'Inter_700Bold',
  },
  middle: {
    flex: 1,
    gap: 5,
  },
  name: {
    fontSize: 15,
    color: Colors.text,
    fontFamily: 'Inter_600SemiBold',
    lineHeight: 20,
  },
  meta: {
    fontSize: 12,
    color: Colors.textMuted,
    fontFamily: 'Inter_400Regular',
  },
  barTrack: {
    height: 5,
    borderRadius: 999,
    backgroundColor: Colors.progressTrack,
    overflow: 'hidden',
    marginTop: 2,
  },
  barFill: {
    height: 5,
    borderRadius: 999,
  },
  right: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  pctWrapper: {
    alignItems: 'center',
  },
  pct: {
    fontSize: 16,
    fontFamily: 'Inter_700Bold',
  },
  doneBadge: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
