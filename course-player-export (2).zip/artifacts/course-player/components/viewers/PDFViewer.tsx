import { Feather } from '@expo/vector-icons';
import * as FileSystem from 'expo-file-system/legacy';
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { WebView } from 'react-native-webview';
import { Colors } from '@/constants/colors';

interface Props {
  uri: string;
}

export function PDFViewer({ uri }: Props) {
  const webRef = useRef<WebView>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pdfBase64, setPdfBase64] = useState<string | null>(null);

  useEffect(() => {
    loadPdf();
  }, [uri]);

  const loadPdf = async () => {
    setLoading(true);
    setError(null);
    setPdfBase64(null);
    try {
      if (Platform.OS === 'web') {
        setError('PDF viewer not available on web');
        return;
      }
      const fileUri = uri.startsWith('file://') ? uri : `file://${uri}`;
      const info = await FileSystem.getInfoAsync(fileUri);
      if (!info.exists) {
        setError('File not found');
        return;
      }
      const base64 = await FileSystem.readAsStringAsync(fileUri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      setPdfBase64(base64);
    } catch (e: any) {
      setError(e.message ?? 'Could not load PDF');
    } finally {
      setLoading(false);
    }
  };

  if (Platform.OS === 'web') {
    return (
      <View style={styles.center}>
        <Feather name="file-text" size={48} color={Colors.textMuted} />
        <Text style={styles.infoText}>PDF viewer not available on web</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={Colors.accent} />
        <Text style={styles.loadingText}>Reading PDF…</Text>
      </View>
    );
  }

  if (error || !pdfBase64) {
    return (
      <View style={styles.center}>
        <Feather name="alert-circle" size={48} color={Colors.error} />
        <Text style={styles.errorText}>{error ?? 'Could not load PDF'}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={loadPdf}>
          <Text style={styles.retryText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const dataUri = `data:application/pdf;base64,${pdfBase64}`;

  return (
    <View style={styles.container}>
      <WebView
        ref={webRef}
        source={{ uri: dataUri }}
        style={styles.webview}
        originWhitelist={['*']}
        javaScriptEnabled={true}
        scalesPageToFit={true}
        onError={() => setError('WebView failed to display PDF')}
        startInLoadingState={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  webview: { flex: 1, backgroundColor: '#000' },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 14,
    backgroundColor: Colors.bg,
    paddingHorizontal: 32,
  },
  loadingText: { color: Colors.textSecondary, fontFamily: 'Inter_500Medium', fontSize: 14 },
  infoText: { color: Colors.textSecondary, fontFamily: 'Inter_500Medium', fontSize: 14, textAlign: 'center' },
  errorText: { color: Colors.error, fontFamily: 'Inter_600SemiBold', fontSize: 15, textAlign: 'center' },
  retryBtn: {
    backgroundColor: Colors.bgCard,
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  retryText: { color: Colors.accent, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
});
