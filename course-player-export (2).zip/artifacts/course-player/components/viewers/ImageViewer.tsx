import { Feather } from '@expo/vector-icons';
import React from 'react';
import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  clamp,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { Colors } from '@/constants/colors';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');
const MIN_SCALE = 1;
const MAX_SCALE = 6;

interface Props {
  uri: string;
  name?: string;
}

export function ImageViewer({ uri, name }: Props) {
  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const savedX = useSharedValue(0);
  const savedY = useSharedValue(0);

  const pinchGesture = Gesture.Pinch()
    .onUpdate((e) => {
      scale.value = clamp(savedScale.value * e.scale, MIN_SCALE, MAX_SCALE);
    })
    .onEnd(() => {
      savedScale.value = scale.value;
      if (scale.value < 1.05) {
        scale.value = withSpring(1, { damping: 20 });
        savedScale.value = 1;
        translateX.value = withSpring(0, { damping: 20 });
        translateY.value = withSpring(0, { damping: 20 });
        savedX.value = 0;
        savedY.value = 0;
      }
    });

  const panGesture = Gesture.Pan()
    .onStart(() => {
      savedX.value = translateX.value;
      savedY.value = translateY.value;
    })
    .onUpdate((e) => {
      if (scale.value <= 1) return;
      const maxX = (SCREEN_W * (scale.value - 1)) / 2;
      const maxY = (SCREEN_H * (scale.value - 1)) / 2;
      translateX.value = clamp(savedX.value + e.translationX, -maxX, maxX);
      translateY.value = clamp(savedY.value + e.translationY, -maxY, maxY);
    })
    .onEnd(() => {
      savedX.value = translateX.value;
      savedY.value = translateY.value;
    });

  const doubleTapGesture = Gesture.Tap()
    .numberOfTaps(2)
    .onEnd((e) => {
      if (scale.value > 1.5) {
        scale.value = withSpring(1, { damping: 20 });
        savedScale.value = 1;
        translateX.value = withSpring(0, { damping: 20 });
        translateY.value = withSpring(0, { damping: 20 });
        savedX.value = 0;
        savedY.value = 0;
      } else {
        const targetScale = 3;
        const centerX = SCREEN_W / 2;
        const centerY = SCREEN_H / 2;
        const dx = (centerX - e.x) * (targetScale - 1);
        const dy = (centerY - e.y) * (targetScale - 1);
        const maxX = (SCREEN_W * (targetScale - 1)) / 2;
        const maxY = (SCREEN_H * (targetScale - 1)) / 2;
        scale.value = withSpring(targetScale, { damping: 20 });
        savedScale.value = targetScale;
        translateX.value = withSpring(clamp(dx, -maxX, maxX), { damping: 20 });
        translateY.value = withSpring(clamp(dy, -maxY, maxY), { damping: 20 });
        savedX.value = clamp(dx, -maxX, maxX);
        savedY.value = clamp(dy, -maxY, maxY);
      }
    });

  const composed = Gesture.Simultaneous(
    Gesture.Exclusive(doubleTapGesture),
    pinchGesture,
    panGesture,
  );

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: scale.value },
    ],
  }));

  return (
    <View style={styles.container}>
      <GestureDetector gesture={composed}>
        <View style={styles.wrapper}>
          <Animated.View style={[styles.imageContainer, animatedStyle]}>
            <Image
              source={{ uri }}
              style={styles.image}
              resizeMode="contain"
            />
          </Animated.View>
        </View>
      </GestureDetector>
      <View style={styles.hint} pointerEvents="none">
        <Feather name="zoom-in" size={13} color="rgba(255,255,255,0.4)" />
        <Text style={styles.hintText}>Pinch to zoom · Double-tap to fit</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  wrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  imageContainer: {
    width: SCREEN_W,
    height: SCREEN_H,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: SCREEN_W,
    height: SCREEN_H,
  },
  hint: {
    position: 'absolute',
    bottom: 16,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  hintText: {
    color: 'rgba(255,255,255,0.35)',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
  },
});
