import { Feather } from '@expo/vector-icons';
import { Asset } from 'expo-asset';
import * as FileSystem from 'expo-file-system/legacy';
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { WebView } from 'react-native-webview';
import { Colors } from '@/constants/colors';

interface Props {
  uri: string;
}

const MAMMOTH_ASSET = require('../../assets/js/mammoth.min.dat');

function buildDocxHtml(mammothJs: string, docxBase64: string): string {
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; padding: 20px 24px; background: #0A0C10; color: #E8EDFF; font-family: Georgia, serif; line-height: 1.75; font-size: 15px; }
  #content { max-width: 680px; margin: 0 auto; }
  h1 { font-size: 22px; font-family: sans-serif; color: #F0F4FF; margin: 20px 0 10px; }
  h2 { font-size: 18px; font-family: sans-serif; color: #D4DBFF; margin: 16px 0 8px; }
  h3 { font-size: 16px; font-family: sans-serif; color: #B8C4F0; margin: 14px 0 6px; }
  p { margin: 8px 0; }
  ul, ol { padding-left: 20px; }
  li { margin: 4px 0; }
  table { border-collapse: collapse; width: 100%; margin: 12px 0; }
  td, th { border: 1px solid #2A2F3E; padding: 8px 12px; text-align: left; }
  th { background: #1E2330; color: #B8C4F0; }
  strong { color: #F0F4FF; }
  em { color: #B8C4F0; }
  #status { color: #8B93A8; font-family: sans-serif; font-size: 13px; text-align: center; padding: 60px 20px; }
</style>
</head>
<body>
<div id="content"><div id="status">Loading document…</div></div>
<script>
${mammothJs}
</script>
<script>
(function() {
  var b64 = "${docxBase64}";
  var binary = atob(b64);
  var len = binary.length;
  var bytes = new Uint8Array(len);
  for (var i = 0; i < len; i++) { bytes[i] = binary.charCodeAt(i); }
  var buf = bytes.buffer;
  mammoth.convertToHtml({ arrayBuffer: buf })
    .then(function(result) {
      document.getElementById('content').innerHTML = result.value || '<p style="color:#8B93A8;text-align:center">Document is empty.</p>';
    })
    .catch(function(e) {
      document.getElementById('content').innerHTML = '<p style="color:#FF453A;text-align:center">Could not render document: ' + e.message + '</p>';
    });
})();
</script>
</body>
</html>`;
}

export function DocxViewer({ uri }: Props) {
  const [html, setHtml] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    load();
  }, [uri]);

  const load = async () => {
    setLoading(true);
    setError(null);
    setHtml(null);
    try {
      const asset = Asset.fromModule(MAMMOTH_ASSET);
      await asset.downloadAsync();
      const mammothJs = await FileSystem.readAsStringAsync(asset.localUri!, {
        encoding: FileSystem.EncodingType.UTF8,
      });

      const fileUri = uri.startsWith('file://') ? uri : `file://${uri}`;
      const info = await FileSystem.getInfoAsync(fileUri);
      if (!info.exists) throw new Error('File not found');

      const docxBase64 = await FileSystem.readAsStringAsync(fileUri, {
        encoding: FileSystem.EncodingType.Base64,
      });

      setHtml(buildDocxHtml(mammothJs, docxBase64));
    } catch (e: any) {
      setError(e.message ?? 'Could not load document');
    } finally {
      setLoading(false);
    }
  };

  if (Platform.OS === 'web') {
    return (
      <View style={styles.center}>
        <Feather name="file-text" size={40} color={Colors.textMuted} />
        <Text style={styles.infoText}>Document viewer not available on web</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={Colors.accent} />
        <Text style={styles.loadingText}>Loading document…</Text>
      </View>
    );
  }

  if (error || !html) {
    return (
      <View style={styles.center}>
        <Feather name="alert-circle" size={40} color={Colors.error} />
        <Text style={styles.errorText}>{error ?? 'Could not load document'}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={load}>
          <Text style={styles.retryText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <WebView
      source={{ html, baseUrl: '' }}
      style={styles.webview}
      originWhitelist={['*']}
      javaScriptEnabled={true}
      domStorageEnabled={true}
      scalesPageToFit={false}
    />
  );
}

const styles = StyleSheet.create({
  webview: { flex: 1, backgroundColor: '#0A0C10' },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    backgroundColor: Colors.bg,
    paddingHorizontal: 32,
  },
  loadingText: { color: Colors.textSecondary, fontFamily: 'Inter_500Medium', fontSize: 14 },
  infoText: { color: Colors.textSecondary, fontFamily: 'Inter_500Medium', fontSize: 14, textAlign: 'center' },
  errorText: { color: Colors.error, fontFamily: 'Inter_600SemiBold', fontSize: 15, textAlign: 'center' },
  retryBtn: {
    backgroundColor: Colors.bgCard,
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  retryText: { color: Colors.accent, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
});
