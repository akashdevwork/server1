import { Feather } from '@expo/vector-icons';
import * as FileSystem from 'expo-file-system/legacy';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Colors } from '@/constants/colors';

const { width: SCREEN_W } = Dimensions.get('window');

interface Props {
  uri: string;
  name: string;
}

function getLanguage(name: string): string {
  const ext = name.split('.').pop()?.toLowerCase() ?? '';
  const map: Record<string, string> = {
    js: 'JavaScript', ts: 'TypeScript', jsx: 'JSX', tsx: 'TSX',
    py: 'Python', java: 'Java', kt: 'Kotlin', swift: 'Swift',
    c: 'C', cpp: 'C++', cs: 'C#', go: 'Go', rs: 'Rust',
    rb: 'Ruby', php: 'PHP', sh: 'Shell', bash: 'Bash',
    html: 'HTML', css: 'CSS', scss: 'SCSS', json: 'JSON',
    xml: 'XML', yaml: 'YAML', yml: 'YAML', toml: 'TOML',
    md: 'Markdown', txt: 'Text', sql: 'SQL', r: 'R',
    dart: 'Dart', lua: 'Lua', pl: 'Perl', m: 'MATLAB',
  };
  return (map[ext] ?? ext.toUpperCase()) || 'Text';
}

function LineNumbers({ count, scrollY }: { count: number; scrollY: number }) {
  return (
    <View style={lineStyles.container}>
      {Array.from({ length: count }, (_, i) => (
        <Text key={i} style={lineStyles.number}>{i + 1}</Text>
      ))}
    </View>
  );
}

const lineStyles = StyleSheet.create({
  container: {
    paddingTop: 12,
    paddingHorizontal: 8,
    alignItems: 'flex-end',
    backgroundColor: '#0D0F15',
    borderRightWidth: 1,
    borderRightColor: '#1E2330',
    minWidth: 44,
  },
  number: {
    color: '#3A4060',
    fontSize: 12,
    fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
    lineHeight: 20,
    includeFontPadding: false,
  },
});

export function CodeViewer({ uri, name }: Props) {
  const [content, setContent] = useState('');
  const [editedContent, setEditedContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const inputRef = useRef<TextInput>(null);
  const lang = getLanguage(name);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const fileUri = uri.startsWith('file://') ? uri : `file://${uri}`;
      const text = await FileSystem.readAsStringAsync(fileUri, { encoding: FileSystem.EncodingType.UTF8 });
      setContent(text);
      setEditedContent(text);
    } catch (e: any) {
      setError(e.message ?? 'Failed to read file');
    } finally {
      setLoading(false);
    }
  }, [uri]);

  useEffect(() => { load(); }, [load]);

  const handleSave = useCallback(async () => {
    setSaving(true);
    try {
      const fileUri = uri.startsWith('file://') ? uri : `file://${uri}`;
      await FileSystem.writeAsStringAsync(fileUri, editedContent, { encoding: FileSystem.EncodingType.UTF8 });
      setContent(editedContent);
      setIsEditing(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e: any) {
      Alert.alert('Save Failed', e.message ?? 'Could not save file');
    } finally {
      setSaving(false);
    }
  }, [uri, editedContent]);

  const handleDiscard = useCallback(() => {
    Alert.alert('Discard Changes', 'Lose all unsaved changes?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Discard', style: 'destructive', onPress: () => { setEditedContent(content); setIsEditing(false); } },
    ]);
  }, [content]);

  const lineCount = (isEditing ? editedContent : content).split('\n').length;
  const displayText = isEditing ? editedContent : content;

  const highlightSearch = (text: string): string => {
    if (!showSearch || !searchText.trim()) return text;
    return text;
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={Colors.accent} />
        <Text style={styles.muted}>Reading file…</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Feather name="alert-circle" size={40} color={Colors.error} />
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={load}>
          <Text style={styles.retryText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {/* Toolbar */}
      <View style={styles.toolbar}>
        <View style={styles.langBadge}>
          <Text style={styles.langText}>{lang}</Text>
        </View>
        <Text style={styles.lineCount}>{lineCount} lines</Text>
        <View style={{ flex: 1 }} />
        <TouchableOpacity style={styles.toolBtn} onPress={() => setShowSearch(s => !s)}>
          <Feather name="search" size={16} color={showSearch ? Colors.accent : Colors.textSecondary} />
        </TouchableOpacity>
        {isEditing ? (
          <>
            <TouchableOpacity style={styles.toolBtn} onPress={handleDiscard}>
              <Feather name="x" size={16} color={Colors.error} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.toolBtn, styles.saveBtn]} onPress={handleSave} disabled={saving}>
              {saving ? <ActivityIndicator size="small" color="#fff" /> : <Feather name="save" size={16} color="#fff" />}
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity style={styles.toolBtn} onPress={() => { setIsEditing(true); setTimeout(() => inputRef.current?.focus(), 100); }}>
            <Feather name="edit-2" size={16} color={Colors.textSecondary} />
          </TouchableOpacity>
        )}
      </View>

      {/* Search bar */}
      {showSearch && (
        <View style={styles.searchBar}>
          <Feather name="search" size={14} color={Colors.textMuted} />
          <TextInput
            style={styles.searchInput}
            placeholder="Find in file…"
            placeholderTextColor={Colors.textMuted}
            value={searchText}
            onChangeText={setSearchText}
            autoCorrect={false}
            autoCapitalize="none"
          />
          {searchText.length > 0 && (
            <Text style={styles.matchCount}>
              {(displayText.split(searchText).length - 1)} matches
            </Text>
          )}
          <TouchableOpacity onPress={() => { setSearchText(''); setShowSearch(false); }}>
            <Feather name="x" size={14} color={Colors.textMuted} />
          </TouchableOpacity>
        </View>
      )}

      {/* Code editor area */}
      <ScrollView
        style={styles.scrollArea}
        horizontal={true}
        nestedScrollEnabled={true}
        keyboardShouldPersistTaps="handled"
      >
        <ScrollView nestedScrollEnabled={true}>
          <View style={styles.codeRow}>
            <LineNumbers count={lineCount} scrollY={0} />
            {isEditing ? (
              <TextInput
                ref={inputRef}
                style={styles.codeInput}
                value={editedContent}
                onChangeText={setEditedContent}
                multiline
                autoCapitalize="none"
                autoCorrect={false}
                spellCheck={false}
                keyboardType="default"
                scrollEnabled={false}
                textAlignVertical="top"
              />
            ) : (
              <Text
                style={[
                  styles.codeText,
                  searchText && showSearch && { opacity: 1 },
                ]}
                selectable
              >
                {displayText}
              </Text>
            )}
          </View>
        </ScrollView>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const MONO = Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' });

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D0F15' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, backgroundColor: Colors.bg },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#111318',
    borderBottomWidth: 1,
    borderBottomColor: '#1E2330',
  },
  langBadge: {
    backgroundColor: '#1E2330',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  langText: { color: Colors.accent, fontSize: 11, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.3 },
  lineCount: { color: Colors.textMuted, fontSize: 11, fontFamily: 'Inter_400Regular' },
  toolBtn: {
    width: 34,
    height: 34,
    borderRadius: 8,
    backgroundColor: '#1E2330',
    alignItems: 'center',
    justifyContent: 'center',
  },
  saveBtn: { backgroundColor: Colors.accent },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#111318',
    borderBottomWidth: 1,
    borderBottomColor: '#1E2330',
  },
  searchInput: {
    flex: 1,
    color: Colors.text,
    fontFamily: MONO,
    fontSize: 13,
    height: 32,
    paddingVertical: 0,
  },
  matchCount: { color: Colors.textMuted, fontSize: 11, fontFamily: 'Inter_400Regular' },
  scrollArea: { flex: 1 },
  codeRow: { flexDirection: 'row', alignItems: 'flex-start' },
  codeText: {
    color: '#C9D1E8',
    fontFamily: MONO,
    fontSize: 13,
    lineHeight: 20,
    paddingHorizontal: 12,
    paddingTop: 12,
    paddingBottom: 40,
    includeFontPadding: false,
  },
  codeInput: {
    color: '#C9D1E8',
    fontFamily: MONO,
    fontSize: 13,
    lineHeight: 20,
    paddingHorizontal: 12,
    paddingTop: 12,
    paddingBottom: 40,
    minWidth: SCREEN_W - 60,
    includeFontPadding: false,
  },
  muted: { color: Colors.textMuted, fontFamily: 'Inter_400Regular', fontSize: 13 },
  errorText: { color: Colors.error, fontFamily: 'Inter_600SemiBold', fontSize: 15, textAlign: 'center' },
  retryBtn: { backgroundColor: Colors.bgCard, borderRadius: 12, paddingHorizontal: 20, paddingVertical: 10 },
  retryText: { color: Colors.accent, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
});
