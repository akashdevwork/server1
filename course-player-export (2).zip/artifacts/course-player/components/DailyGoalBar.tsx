import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Colors } from '@/constants/colors';

interface Props {
  minutesWatched: number;
  dailyTarget?: number;
}

export function DailyGoalBar({ minutesWatched, dailyTarget = 20 }: Props) {
  const pct = Math.min((minutesWatched / dailyTarget) * 100, 100);
  const done = pct >= 100;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.label}>
          {done ? '🎯 Daily goal achieved!' : '🎯 Daily goal'}
        </Text>
        <Text style={[styles.count, done && styles.countDone]}>
          {minutesWatched}m / {dailyTarget}m
        </Text>
      </View>
      <View style={styles.track}>
        <View style={[styles.fill, { width: `${pct}%` as any }, done && styles.fillDone]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: 8 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  label: {
    fontSize: 13,
    color: Colors.textSecondary,
    fontFamily: 'Inter_500Medium',
  },
  count: {
    fontSize: 13,
    color: Colors.textSecondary,
    fontFamily: 'Inter_700Bold',
  },
  countDone: { color: Colors.duo },
  track: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.progressTrack,
    overflow: 'hidden',
  },
  fill: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.accent,
  },
  fillDone: { backgroundColor: Colors.duo },
});
