import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Colors } from '@/constants/colors';
import { CourseFile } from '@/context/CourseContext';

interface Props {
  file: CourseFile;
  index: number;
  onPress: () => void;
}

function FileIcon({ type }: { type: CourseFile['type'] }) {
  switch (type) {
    case 'video':
      return <Feather name="play-circle" size={18} color="#4F8EF7" />;
    case 'pdf':
      return <MaterialCommunityIcons name="file-pdf-box" size={18} color="#FF6B6B" />;
    case 'image':
      return <Ionicons name="image-outline" size={18} color="#00C6AE" />;
    case 'code':
      return <MaterialCommunityIcons name="code-braces" size={18} color="#FFB800" />;
    case 'docx':
      return <MaterialCommunityIcons name="file-word" size={18} color="#CE82FF" />;
    default:
      return <Feather name="file" size={18} color={Colors.textMuted} />;
  }
}

function formatTime(seconds: number): string {
  if (!seconds) return '';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function fileTypeLabel(type: CourseFile['type']): string {
  switch (type) {
    case 'video': return 'Video';
    case 'pdf': return 'PDF';
    case 'image': return 'Image';
    case 'code': return 'Code';
    case 'docx': return 'Doc';
    default: return 'File';
  }
}

function fileTypeColor(type: CourseFile['type']): string {
  switch (type) {
    case 'video': return '#4F8EF7';
    case 'pdf': return '#FF6B6B';
    case 'image': return '#00C6AE';
    case 'code': return '#FFB800';
    case 'docx': return '#CE82FF';
    default: return Colors.textMuted;
  }
}

export function FileListItem({ file, index, onPress }: Props) {
  const cleanName = file.name.replace(/^\d+[\.\-_\s]+/, '').replace(/\.[^/.]+$/, '');
  const hasProgress = file.type === 'video' && (file.watchedSeconds ?? 0) > 0 && !file.completed;
  const pct = hasProgress
    ? Math.min(100, Math.round(((file.watchedSeconds ?? 0) / (file.durationSeconds ?? 1)) * 100))
    : 0;
  const remaining = hasProgress
    ? Math.max(0, (file.durationSeconds ?? 0) - (file.watchedSeconds ?? 0))
    : 0;

  const typeColor = fileTypeColor(file.type);
  const isCompleted = file.completed;

  return (
    <TouchableOpacity
      style={[styles.container, isCompleted && styles.containerDone]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      {isCompleted ? (
        <View style={styles.completedBar} />
      ) : hasProgress ? (
        <View style={[styles.accentBar, { backgroundColor: typeColor }]} />
      ) : (
        <View style={styles.noBar} />
      )}

      <View style={[styles.iconWrapper, { backgroundColor: `${typeColor}15` }]}>
        <FileIcon type={file.type} />
      </View>

      <View style={styles.info}>
        <Text style={[styles.name, isCompleted && styles.nameDone]} numberOfLines={2}>
          {cleanName}
        </Text>
        <View style={styles.metaRow}>
          <View style={[styles.typePill, { backgroundColor: `${typeColor}18`, borderColor: `${typeColor}35` }]}>
            <Text style={[styles.typeText, { color: typeColor }]}>{fileTypeLabel(file.type)}</Text>
          </View>
          {hasProgress && remaining > 0 && (
            <Text style={styles.timeLeft}>{formatTime(remaining)} left</Text>
          )}
        </View>
        {hasProgress && (
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${pct}%` as any, backgroundColor: typeColor }]} />
          </View>
        )}
      </View>

      <View style={styles.right}>
        {isCompleted ? (
          <View style={styles.checkCircle}>
            <Feather name="check" size={13} color={Colors.duo} />
          </View>
        ) : (
          <View style={styles.indexBadge}>
            <Text style={styles.indexText}>{index + 1}</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 13,
    paddingRight: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderSubtle,
    gap: 12,
    backgroundColor: Colors.bg,
  },
  containerDone: {
    backgroundColor: 'rgba(88, 204, 2, 0.03)',
  },
  accentBar: {
    width: 3,
    height: 36,
    borderRadius: 2,
    marginLeft: 0,
  },
  completedBar: {
    width: 3,
    height: 36,
    borderRadius: 2,
    backgroundColor: Colors.duo,
    marginLeft: 0,
  },
  noBar: {
    width: 3,
    height: 36,
    marginLeft: 0,
  },
  iconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: {
    flex: 1,
    gap: 5,
  },
  name: {
    fontSize: 14,
    color: Colors.text,
    fontFamily: 'Inter_500Medium',
    lineHeight: 19,
  },
  nameDone: {
    color: Colors.textSecondary,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  typePill: {
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderWidth: 1,
  },
  typeText: {
    fontSize: 10,
    fontFamily: 'Inter_600SemiBold',
    letterSpacing: 0.3,
  },
  timeLeft: {
    fontSize: 11,
    color: Colors.textMuted,
    fontFamily: 'Inter_400Regular',
  },
  progressTrack: {
    height: 3,
    borderRadius: 2,
    backgroundColor: Colors.progressTrack,
    overflow: 'hidden',
  },
  progressFill: {
    height: 3,
    borderRadius: 2,
  },
  right: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkCircle: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: Colors.duoDim,
    borderWidth: 1,
    borderColor: Colors.duoBorder,
    alignItems: 'center',
    justifyContent: 'center',
  },
  indexBadge: {
    width: 26,
    height: 26,
    borderRadius: 8,
    backgroundColor: Colors.bgSurface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  indexText: {
    fontSize: 11,
    color: Colors.textMuted,
    fontFamily: 'Inter_600SemiBold',
  },
});
