import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import React from 'react';
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { SkeletonCard } from '@/components/HomeWidgets';
import { Colors, getCourseAccent } from '@/constants/colors';
import { Course, useCourses } from '@/context/CourseContext';
import { useNotifications } from '@/hooks/useNotifications';

function formatRemaining(watched: number, duration: number): string {
  const rem = Math.max(0, duration - watched);
  if (rem <= 0) return 'Done';
  const m = Math.floor(rem / 60);
  const s = Math.floor(rem % 60);
  if (m > 60) return `${Math.floor(m / 60)}h ${m % 60}m left`;
  return `${m}:${s.toString().padStart(2, '0')} left`;
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

function getMotivationIcon(streak: number, dailyPct: number) {
  if (dailyPct >= 100) return { icon: 'trophy' as const, lib: 'mci', color: Colors.gold };
  if (streak >= 7) return { icon: 'fire' as const, lib: 'mci', color: Colors.fire };
  if (streak >= 3) return { icon: 'rocket-launch-outline' as const, lib: 'mci', color: Colors.accent };
  return { icon: 'lightbulb-on-outline' as const, lib: 'mci', color: Colors.gold };
}

function getMotivationText(streak: number, dailyPct: number): string {
  if (dailyPct >= 100) return 'Daily goal crushed! Incredible work!';
  if (streak >= 7) return `${streak} day streak — you\'re on fire!`;
  if (streak >= 3) return `${streak} days strong! Keep building that habit.`;
  if (streak === 1) return 'Day 1 started — consistency is everything!';
  return 'Ready to learn something new today?';
}

function getInitials(name: string): string {
  const words = name.replace(/[-_]/g, ' ').split(' ').filter(Boolean);
  if (words.length >= 2) return (words[0][0] + words[1][0]).toUpperCase();
  return name.slice(0, 2).toUpperCase();
}

function MiniCourseCard({ course, onPress }: { course: Course; onPress: () => void }) {
  const accent = getCourseAccent(course.name);
  return (
    <TouchableOpacity style={styles.miniCard} onPress={onPress} activeOpacity={0.75}>
      <View style={[styles.miniAvatar, { backgroundColor: `${accent}18`, borderColor: `${accent}35` }]}>
        <Text style={[styles.miniAvatarText, { color: accent }]}>{getInitials(course.name)}</Text>
      </View>
      <Text style={styles.miniName} numberOfLines={2}>{course.name}</Text>
      <View style={styles.miniMeta}>
        <Feather name="layers" size={10} color={Colors.textMuted} />
        <Text style={styles.miniMetaText}>{course.files.length} files</Text>
      </View>
      <View style={styles.miniBarTrack}>
        <View style={[styles.miniBarFill, { width: `${course.percentComplete}%` as any, backgroundColor: accent }]} />
      </View>
      <Text style={[styles.miniPct, { color: accent }]}>{course.percentComplete}%</Text>
    </TouchableOpacity>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const {
    resume, dailyStudy, courses, isLoading, loadCourses,
    streak, totalXP,
  } = useCourses();
  useNotifications();

  const scale = useSharedValue(1);
  const resumeAnimStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handleResumePress = () => {
    if (!resume) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    scale.value = withSpring(0.97, {}, () => { scale.value = withSpring(1); });
    router.push({
      pathname: '/player/[courseId]/[fileName]',
      params: { courseId: resume.courseId, fileName: resume.fileName },
    });
  };

  const handleRefresh = async () => {
    Haptics.selectionAsync();
    await loadCourses();
  };

  const dailyPct = Math.min(100, (dailyStudy.minutesWatched / 20) * 100);
  const motivInfo = getMotivationIcon(streak, dailyPct);
  const goalDone = dailyPct >= 100;

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={[
        styles.scrollContent,
        {
          paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 20),
          paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 32),
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <Animated.View entering={FadeIn.duration(350)} style={styles.header}>
        <View>
          <Text style={styles.greeting}>{getGreeting()}</Text>
          <Text style={styles.title}>Your Learning</Text>
        </View>
        <TouchableOpacity style={styles.allCoursesBtn} onPress={() => router.push('/courses')} activeOpacity={0.7}>
          <Feather name="grid" size={14} color={Colors.accent} />
          <Text style={styles.allCoursesBtnText}>All Courses</Text>
        </TouchableOpacity>
      </Animated.View>

      {/* Motivation banner */}
      <Animated.View entering={FadeInDown.duration(350).delay(60)} style={styles.motivationBanner}>
        <MaterialCommunityIcons name={motivInfo.icon} size={18} color={motivInfo.color} />
        <Text style={styles.motivationText}>{getMotivationText(streak, dailyPct)}</Text>
      </Animated.View>

      {/* Stats row */}
      <Animated.View entering={FadeInDown.duration(350).delay(120)} style={styles.statsRow}>
        <View style={styles.statItem}>
          <MaterialCommunityIcons name="fire" size={20} color={Colors.fire} />
          <Text style={[styles.statValue, { color: Colors.fire }]}>{streak}</Text>
          <Text style={styles.statLabel}>Streak</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Feather name="zap" size={18} color={Colors.gold} />
          <Text style={[styles.statValue, { color: Colors.gold }]}>{totalXP}</Text>
          <Text style={styles.statLabel}>Total XP</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Feather name="clock" size={18} color={goalDone ? Colors.duo : Colors.textMuted} />
          <Text style={[styles.statValue, { color: goalDone ? Colors.duo : Colors.text }]}>
            {dailyStudy.minutesWatched}m
          </Text>
          <Text style={styles.statLabel}>Today</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <MaterialCommunityIcons name="target" size={18} color={goalDone ? Colors.duo : Colors.accent} />
          <Text style={[styles.statValue, { color: goalDone ? Colors.duo : Colors.accent }]}>
            {goalDone ? 'Done' : `${Math.round(dailyPct)}%`}
          </Text>
          <Text style={styles.statLabel}>Daily Goal</Text>
        </View>
      </Animated.View>

      {/* Daily goal bar */}
      <Animated.View entering={FadeInDown.duration(350).delay(170)} style={styles.goalCard}>
        <View style={styles.goalHeader}>
          <MaterialCommunityIcons name="target" size={14} color={goalDone ? Colors.duo : Colors.textMuted} />
          <Text style={styles.goalLabel}>Daily Goal — 20 minutes</Text>
          <Text style={[styles.goalCount, goalDone && { color: Colors.duo }]}>
            {dailyStudy.minutesWatched}m / 20m
          </Text>
        </View>
        <View style={styles.goalTrack}>
          <View style={[styles.goalFill, { width: `${dailyPct}%` as any }, goalDone && { backgroundColor: Colors.duo }]} />
        </View>
      </Animated.View>

      {/* Resume card */}
      <Animated.View entering={FadeInDown.duration(350).delay(220)} style={resumeAnimStyle}>
        {resume ? (
          <Pressable style={styles.resumeCard} onPress={handleResumePress}>
            <View style={styles.resumeGlow} />
            <View style={styles.resumeTop}>
              <View style={styles.continueBadge}>
                <Feather name="play" size={10} color={Colors.accent} />
                <Text style={styles.continueBadgeText}>Continue</Text>
              </View>
              {resume.watchedSeconds > 0 && resume.durationSeconds > 0 && (
                <View style={styles.timeLeftPill}>
                  <Feather name="clock" size={10} color={Colors.textMuted} />
                  <Text style={styles.timeLeftText}>
                    {formatRemaining(resume.watchedSeconds, resume.durationSeconds)}
                  </Text>
                </View>
              )}
            </View>
            <Text style={styles.resumeCourseName} numberOfLines={1}>{resume.courseName}</Text>
            <Text style={styles.resumeFileName} numberOfLines={2}>
              {resume.fileName.replace(/^\d+[\.\-_\s]+/, '').replace(/\.[^/.]+$/, '')}
            </Text>
            {resume.durationSeconds > 0 && (
              <View style={styles.resumeProgressTrack}>
                <View
                  style={[
                    styles.resumeProgressFill,
                    { width: `${Math.min(100, (resume.watchedSeconds / resume.durationSeconds) * 100)}%` as any },
                  ]}
                />
              </View>
            )}
            <View style={styles.resumePlayBtn}>
              <Feather name="play" size={15} color="#fff" />
              <Text style={styles.resumePlayText}>Resume Learning</Text>
            </View>
          </Pressable>
        ) : (
          <View style={styles.emptyCard}>
            <Feather name="book-open" size={44} color={Colors.textMuted} />
            <Text style={styles.emptyTitle}>No course in progress</Text>
            <Text style={styles.emptySub}>Put your course folders in /storage/emulated/0/Courses</Text>
            <TouchableOpacity style={styles.browseCourseBtn} onPress={() => router.push('/courses')}>
              <Feather name="grid" size={14} color={Colors.accent} />
              <Text style={styles.browseCourseText}>Browse Courses</Text>
            </TouchableOpacity>
          </View>
        )}
      </Animated.View>

      {/* Continue Learning */}
      {isLoading ? (
        <Animated.View entering={FadeInDown.duration(350).delay(300)}>
          <Text style={styles.sectionTitle}>Continue Learning</Text>
          <SkeletonCard height={72} />
          <SkeletonCard height={72} />
        </Animated.View>
      ) : courses.length > 0 ? (
        <Animated.View entering={FadeInDown.duration(350).delay(300)}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Continue Learning</Text>
            <TouchableOpacity onPress={() => router.push('/courses')} style={styles.seeAllBtn}>
              <Text style={styles.seeAllText}>See all</Text>
              <Feather name="chevron-right" size={14} color={Colors.accent} />
            </TouchableOpacity>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.miniScroll}>
            {courses.slice(0, 6).map(course => (
              <MiniCourseCard
                key={course.id}
                course={course}
                onPress={() => {
                  Haptics.selectionAsync();
                  router.push({ pathname: '/course/[id]', params: { id: course.id } });
                }}
              />
            ))}
          </ScrollView>
        </Animated.View>
      ) : null}

      {/* Refresh */}
      <Animated.View entering={FadeInDown.duration(350).delay(380)}>
        <TouchableOpacity style={styles.refreshBtn} onPress={handleRefresh} activeOpacity={0.7} disabled={isLoading}>
          {isLoading
            ? <ActivityIndicator size="small" color={Colors.accent} />
            : <Feather name="refresh-cw" size={14} color={Colors.textMuted} />
          }
          <Text style={styles.refreshText}>{isLoading ? 'Scanning courses…' : 'Refresh Courses'}</Text>
        </TouchableOpacity>
        <Text style={styles.folderPath}>/storage/emulated/0/Courses</Text>
      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: Colors.bg },
  scrollContent: { paddingHorizontal: 18, gap: 14 },

  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  greeting: { fontSize: 12, color: Colors.textMuted, fontFamily: 'Inter_400Regular' },
  title: { fontSize: 28, color: Colors.text, fontFamily: 'Inter_700Bold', marginTop: 2 },
  allCoursesBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.accentGlow, borderRadius: 20,
    paddingHorizontal: 14, paddingVertical: 8,
    borderWidth: 1, borderColor: 'rgba(79,142,247,0.25)',
  },
  allCoursesBtnText: { fontSize: 13, color: Colors.accent, fontFamily: 'Inter_600SemiBold' },

  motivationBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.bgCard,
    borderRadius: 14, paddingHorizontal: 16, paddingVertical: 12,
    borderWidth: 1, borderColor: Colors.border,
  },
  motivationText: { flex: 1, fontSize: 13, color: Colors.textSecondary, fontFamily: 'Inter_500Medium' },

  statsRow: {
    flexDirection: 'row',
    backgroundColor: Colors.bgCard,
    borderRadius: 16, borderWidth: 1, borderColor: Colors.border,
    paddingVertical: 14, paddingHorizontal: 8,
  },
  statItem: { flex: 1, alignItems: 'center', gap: 4 },
  statValue: { fontSize: 18, fontFamily: 'Inter_700Bold', color: Colors.text },
  statLabel: { fontSize: 10, color: Colors.textMuted, fontFamily: 'Inter_500Medium' },
  statDivider: { width: 1, backgroundColor: Colors.border, marginVertical: 4 },

  goalCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: Colors.border,
    gap: 10,
  },
  goalHeader: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  goalLabel: { flex: 1, fontSize: 12, color: Colors.textMuted, fontFamily: 'Inter_500Medium' },
  goalCount: { fontSize: 12, color: Colors.textSecondary, fontFamily: 'Inter_700Bold' },
  goalTrack: { height: 8, borderRadius: 4, backgroundColor: Colors.progressTrack, overflow: 'hidden' },
  goalFill: { height: 8, borderRadius: 4, backgroundColor: Colors.accent },

  resumeCard: {
    backgroundColor: Colors.bgCard, borderRadius: 22, padding: 20,
    borderWidth: 1, borderColor: 'rgba(79,142,247,0.3)', overflow: 'hidden', gap: 10,
  },
  resumeGlow: {
    position: 'absolute', top: -50, right: -50,
    width: 180, height: 180, borderRadius: 90,
    backgroundColor: 'rgba(79,142,247,0.07)',
  },
  resumeTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  continueBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.accentGlow, borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 4,
    borderWidth: 1, borderColor: 'rgba(79,142,247,0.25)',
  },
  continueBadgeText: {
    fontSize: 11, color: Colors.accent, fontFamily: 'Inter_600SemiBold',
    textTransform: 'uppercase', letterSpacing: 0.5,
  },
  timeLeftPill: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  timeLeftText: { fontSize: 12, color: Colors.textMuted, fontFamily: 'Inter_400Regular' },
  resumeCourseName: { fontSize: 11, color: Colors.textMuted, fontFamily: 'Inter_500Medium' },
  resumeFileName: { fontSize: 19, color: Colors.text, fontFamily: 'Inter_700Bold', lineHeight: 25 },
  resumeProgressTrack: { height: 6, borderRadius: 3, backgroundColor: Colors.progressTrack, overflow: 'hidden' },
  resumeProgressFill: { height: 6, borderRadius: 3, backgroundColor: Colors.accent },
  resumePlayBtn: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.accent, borderRadius: 14,
    paddingVertical: 13, paddingHorizontal: 20, gap: 8, alignSelf: 'flex-start', marginTop: 4,
  },
  resumePlayText: { fontSize: 15, color: '#fff', fontFamily: 'Inter_700Bold' },

  emptyCard: {
    backgroundColor: Colors.bgCard, borderRadius: 22, padding: 36,
    alignItems: 'center', gap: 10, borderWidth: 1,
    borderColor: Colors.border, borderStyle: 'dashed',
  },
  emptyTitle: { fontSize: 16, color: Colors.textSecondary, fontFamily: 'Inter_600SemiBold' },
  emptySub: { fontSize: 12, color: Colors.textMuted, fontFamily: 'Inter_400Regular', textAlign: 'center' },
  browseCourseBtn: {
    marginTop: 4, flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.accentGlow, borderRadius: 12,
    paddingVertical: 10, paddingHorizontal: 20,
    borderWidth: 1, borderColor: 'rgba(79,142,247,0.3)',
  },
  browseCourseText: { fontSize: 14, color: Colors.accent, fontFamily: 'Inter_600SemiBold' },

  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontSize: 17, color: Colors.text, fontFamily: 'Inter_700Bold', marginBottom: 12 },
  seeAllBtn: { flexDirection: 'row', alignItems: 'center', gap: 2, marginBottom: 12 },
  seeAllText: { fontSize: 13, color: Colors.accent, fontFamily: 'Inter_600SemiBold' },

  miniScroll: { gap: 10, paddingRight: 4 },
  miniCard: {
    width: 148, backgroundColor: Colors.bgCard,
    borderRadius: 16, padding: 14,
    borderWidth: 1, borderColor: Colors.border, gap: 7,
  },
  miniAvatar: {
    width: 46, height: 46, borderRadius: 13,
    borderWidth: 1, alignItems: 'center', justifyContent: 'center',
  },
  miniAvatarText: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  miniName: { fontSize: 13, color: Colors.text, fontFamily: 'Inter_600SemiBold', lineHeight: 17 },
  miniMeta: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  miniMetaText: { fontSize: 10, color: Colors.textMuted, fontFamily: 'Inter_400Regular' },
  miniBarTrack: { height: 5, borderRadius: 3, backgroundColor: Colors.progressTrack, overflow: 'hidden' },
  miniBarFill: { height: 5, borderRadius: 3 },
  miniPct: { fontSize: 13, fontFamily: 'Inter_700Bold' },

  refreshBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.bgCard, borderRadius: 14,
    paddingVertical: 14, borderWidth: 1, borderColor: Colors.border,
  },
  refreshText: { fontSize: 14, color: Colors.textMuted, fontFamily: 'Inter_500Medium' },
  folderPath: {
    textAlign: 'center', fontSize: 11, color: Colors.textMuted,
    fontFamily: 'Inter_400Regular', marginTop: 6, opacity: 0.5,
  },
});
