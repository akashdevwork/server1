import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router, useLocalSearchParams } from 'expo-router';
import React from 'react';
import {
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import Svg, { Circle } from 'react-native-svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { FileListItem } from '@/components/FileListItem';
import { Colors, getCourseAccent } from '@/constants/colors';
import { useCourses } from '@/context/CourseContext';

export default function CourseDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getCourseById } = useCourses();
  const course = getCourseById(id);

  if (!course) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={Colors.text} />
        </TouchableOpacity>
        <View style={styles.center}>
          <Feather name="alert-circle" size={40} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>Course not found</Text>
        </View>
      </View>
    );
  }

  const accent = getCourseAccent(course.name);
  const pct = course.percentComplete;
  const isDone = pct === 100;

  const size = 80;
  const strokeWidth = 7;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (pct / 100) * circumference;
  const center = size / 2;

  const nextFile = course.files.find(f => !f.completed);
  const totalFiles = course.files.length;
  const completedFiles = course.files.filter(f => f.completed).length;

  const handleFilePress = (fileName: string) => {
    Haptics.selectionAsync();
    router.push({
      pathname: '/player/[courseId]/[fileName]',
      params: { courseId: course.id, fileName },
    });
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 0) }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtnRow}>
          <Feather name="arrow-left" size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.title} numberOfLines={1}>{course.name}</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Progress Banner */}
      <Animated.View entering={FadeIn.duration(300)} style={[styles.progressBanner, { borderColor: `${accent}35` }]}>
        <View style={[styles.bannerAccent, { backgroundColor: accent }]} />
        <View style={styles.bannerTop}>
          {/* Circular progress ring */}
          <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
            <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
              <Circle cx={center} cy={center} r={radius} stroke={Colors.progressTrack} strokeWidth={strokeWidth} fill="transparent" />
              <Circle
                cx={center} cy={center} r={radius}
                stroke={accent} strokeWidth={strokeWidth} fill="transparent"
                strokeDasharray={circumference} strokeDashoffset={offset}
                strokeLinecap="round" rotation="-90" origin={`${center}, ${center}`}
              />
            </Svg>
            {isDone ? (
              <MaterialCommunityIcons name="trophy" size={30} color={accent} />
            ) : (
              <Text style={[styles.pctLabel, { color: accent }]}>{pct}%</Text>
            )}
          </View>

          <View style={styles.progressInfo}>
            <Text style={styles.progressTitle}>
              {isDone ? 'Course Complete!' : 'Course Progress'}
            </Text>
            {isDone && (
              <View style={styles.completedBadge}>
                <Feather name="check-circle" size={12} color={accent} />
                <Text style={[styles.completedText, { color: accent }]}>Well done!</Text>
              </View>
            )}
            <Text style={styles.progressDetail}>
              {completedFiles} of {totalFiles} lessons done
            </Text>
            {nextFile && !isDone && (
              <View style={styles.nextFileChip}>
                <Feather name="arrow-right-circle" size={12} color={accent} />
                <Text style={[styles.nextFileText, { color: accent }]} numberOfLines={1}>
                  Up next: {nextFile.name.replace(/^\d+[\.\-_\s]+/, '').replace(/\.[^/.]+$/, '')}
                </Text>
              </View>
            )}
          </View>
        </View>

        <TouchableOpacity
          style={[styles.startBtn, { backgroundColor: accent }]}
          activeOpacity={0.75}
          onPress={() => {
            const target = nextFile ?? course.files[0];
            if (target) {
              Haptics.selectionAsync();
              router.push({ pathname: '/player/[courseId]/[fileName]', params: { courseId: course.id, fileName: target.name } });
            }
          }}
        >
          <Feather name="play" size={14} color="#fff" />
          <Text style={styles.startBtnText}>
            {isDone ? 'Review Course' : nextFile ? 'Continue Learning' : 'Start from Beginning'}
          </Text>
        </TouchableOpacity>
      </Animated.View>

      {/* File list */}
      <FlatList
        data={course.files}
        keyExtractor={item => item.name}
        getItemLayout={(_, index) => ({ length: 68, offset: 68 * index, index })}
        renderItem={({ item, index }) => (
          <Animated.View entering={FadeInDown.duration(240).delay(index * 30)}>
            <FileListItem file={item} index={index} onPress={() => handleFilePress(item.name)} />
          </Animated.View>
        )}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 20) }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.center}>
            <Feather name="inbox" size={36} color={Colors.textMuted} />
            <Text style={styles.emptyTitle}>No files found</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  backBtnRow: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 },
  backBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center', margin: 16 },
  title: { flex: 1, fontSize: 18, color: Colors.text, fontFamily: 'Inter_700Bold', textAlign: 'center' },
  progressBanner: {
    backgroundColor: Colors.bgCard, margin: 14,
    borderRadius: 20, padding: 18, borderWidth: 1, overflow: 'hidden',
  },
  bannerAccent: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 4 },
  bannerTop: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingLeft: 8 },
  progressInfo: { flex: 1, gap: 5 },
  progressTitle: { fontSize: 15, color: Colors.text, fontFamily: 'Inter_700Bold' },
  completedBadge: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  completedText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  progressDetail: { fontSize: 13, color: Colors.textSecondary, fontFamily: 'Inter_400Regular' },
  nextFileChip: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  nextFileText: { fontSize: 11, fontFamily: 'Inter_500Medium', flex: 1 },
  pctLabel: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  startBtn: {
    marginTop: 14, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', gap: 8, borderRadius: 14, paddingVertical: 13,
  },
  startBtnText: { fontSize: 14, color: '#fff', fontFamily: 'Inter_700Bold' },
  list: { paddingTop: 4 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 40 },
  emptyTitle: { fontSize: 16, color: Colors.textSecondary, fontFamily: 'Inter_600SemiBold' },
});
