import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import React from 'react';
import {
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CourseCard } from '@/components/CourseCard';
import { SkeletonCard } from '@/components/HomeWidgets';
import { Colors } from '@/constants/colors';
import { useCourses } from '@/context/CourseContext';

export default function CoursesScreen() {
  const insets = useSafeAreaInsets();
  const { courses, isLoading, loadCourses, totalXP, streak } = useCourses();

  const handleRefresh = () => {
    Haptics.selectionAsync();
    loadCourses();
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 0) }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.iconBtn}>
          <Feather name="arrow-left" size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>My Courses</Text>
        <TouchableOpacity onPress={handleRefresh} style={[styles.iconBtn, styles.refreshBtn]} disabled={isLoading}>
          <Feather name="refresh-cw" size={18} color={isLoading ? Colors.textMuted : Colors.accent} />
        </TouchableOpacity>
      </View>

      {/* Stats bar */}
      <View style={styles.statsBar}>
        <View style={styles.statItem}>
          <MaterialCommunityIcons name="fire" size={16} color={Colors.fire} />
          <Text style={[styles.statValue, { color: Colors.fire }]}>{streak}</Text>
          <Text style={styles.statLabel}>streak</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Feather name="zap" size={14} color={Colors.gold} />
          <Text style={[styles.statValue, { color: Colors.gold }]}>{totalXP}</Text>
          <Text style={styles.statLabel}>XP</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Feather name="book-open" size={14} color={Colors.accent} />
          <Text style={[styles.statValue, { color: Colors.accent }]}>{courses.length}</Text>
          <Text style={styles.statLabel}>courses</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Feather name="check-circle" size={14} color={Colors.duo} />
          <Text style={[styles.statValue, { color: Colors.duo }]}>
            {courses.reduce((a, c) => a + c.completedVideos, 0)}
          </Text>
          <Text style={styles.statLabel}>done</Text>
        </View>
      </View>

      {/* Content */}
      {isLoading ? (
        <View style={styles.skeletonList}>
          <SkeletonCard height={84} />
          <SkeletonCard height={84} />
          <SkeletonCard height={84} />
          <SkeletonCard height={84} />
        </View>
      ) : courses.length === 0 ? (
        <View style={styles.emptyState}>
          <Feather name="folder" size={56} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>No courses found</Text>
          <Text style={styles.emptyText}>
            Add folders with video, PDF, or other files to{'\n'}/storage/emulated/0/Courses
          </Text>
          <TouchableOpacity style={styles.scanBtn} onPress={handleRefresh}>
            <Feather name="refresh-cw" size={15} color={Colors.accent} />
            <Text style={styles.scanBtnText}>Scan for Courses</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={courses}
          keyExtractor={item => item.id}
          getItemLayout={(_, index) => ({ length: 94, offset: 94 * index, index })}
          renderItem={({ item, index }) => (
            <Animated.View entering={FadeInDown.duration(280).delay(index * 40)}>
              <CourseCard
                course={item}
                onPress={() => {
                  Haptics.selectionAsync();
                  router.push({ pathname: '/course/[id]', params: { id: item.id } });
                }}
              />
            </Animated.View>
          )}
          contentContainerStyle={[
            styles.list,
            { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 20) },
          ]}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  iconBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 },
  refreshBtn: { backgroundColor: Colors.accentGlow },
  title: { flex: 1, fontSize: 20, color: Colors.text, fontFamily: 'Inter_700Bold', textAlign: 'center' },
  statsBar: {
    flexDirection: 'row',
    backgroundColor: Colors.bgCard,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    paddingVertical: 12, paddingHorizontal: 8,
  },
  statItem: { flex: 1, alignItems: 'center', gap: 3 },
  statValue: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  statLabel: { fontSize: 10, color: Colors.textMuted, fontFamily: 'Inter_500Medium' },
  statDivider: { width: 1, backgroundColor: Colors.border, marginVertical: 4 },
  list: { padding: 16 },
  skeletonList: { padding: 16 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 40 },
  emptyTitle: { fontSize: 20, color: Colors.textSecondary, fontFamily: 'Inter_700Bold' },
  emptyText: {
    fontSize: 14, color: Colors.textMuted, fontFamily: 'Inter_400Regular',
    textAlign: 'center', lineHeight: 22,
  },
  scanBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8,
    backgroundColor: Colors.accentGlow, borderRadius: 14,
    paddingVertical: 13, paddingHorizontal: 24,
    borderWidth: 1, borderColor: 'rgba(79,142,247,0.3)',
  },
  scanBtnText: { fontSize: 15, color: Colors.accent, fontFamily: 'Inter_600SemiBold' },
});
